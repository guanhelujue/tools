"""Import a restricted set of reviewed local LiteGraph workflows as parameter templates.

Unknown virtual/bypass/dynamic nodes fail closed. Other architectures should use
an API-format workflow with an explicit local manifest instead of guessing bindings.
"""
import argparse
import copy
import json
from pathlib import Path

import httpx


def graph_to_api(graph, info):
    if "nodes" not in graph:
        return copy.deepcopy(graph)
    links = {link[0]: link for link in graph["links"]}
    result = {}
    for node in graph["nodes"]:
        name = node["type"]
        if name in {"Note", "MarkdownNote"}:
            continue
        if node.get("mode", 0) != 0 or name not in info:
            raise ValueError(f"节点 {node['id']} ({name}) 需要人工适配")
        required = info[name]["input"].get("required", {})
        optional = info[name]["input"].get("optional", {})
        specs = {**required, **optional}
        inputs = {}
        for slot in node.get("inputs", []):
            link_id = slot.get("link")
            if link_id is not None:
                link = links[link_id]
                inputs[slot["name"]] = [str(link[1]), link[2]]
        widgets = list(node.get("widgets_values", []))
        if name == "SaveVideo":
            inputs.update(filename_prefix="Toolcase/result", format="mp4", **{"format.codec": "h264", "format.codec.encoding": "auto"})
        else:
            position = 0
            for field, spec in specs.items():
                kind = spec[0]
                options = spec[1] if len(spec) > 1 and isinstance(spec[1], dict) else {}
                is_widget = isinstance(kind, list) or kind in {"INT", "FLOAT", "STRING", "BOOLEAN", "COMBO"}
                if not is_widget or options.get("forceInput"):
                    continue
                if field in inputs:
                    continue
                if position < len(widgets):
                    inputs[field] = widgets[position]
                    position += 1
                    if options.get("control_after_generate") and position < len(widgets) and widgets[position] in {"fixed", "increment", "decrement", "randomize"}:
                        position += 1
                elif "default" in options:
                    inputs[field] = options["default"]
                elif field in required:
                    raise ValueError(f"缺少 {name}.{field} 的值")
        result[str(node["id"])] = {"class_type": name, "inputs": inputs}
    return result


def make_manifest(api, template_id, name, mode):
    image_nodes = [key for key, n in api.items() if n["class_type"] == "LoadImage"]
    output_nodes = [key for key, n in api.items() if n["class_type"] in {"SaveImage", "SaveVideo", "VHS_VideoCombine"}]
    if not output_nodes:
        raise ValueError("没有支持的成品保存节点")
    fields = []
    grouped = {}
    prompt_count = 0
    for node_id, node in api.items():
        for key, value in node["inputs"].items():
            if isinstance(value, list):
                continue
            if key in {"text", "prompt"} and node["class_type"] not in {"SaveImage", "SaveVideo"}:
                prompt_count += 1
                field_id = "prompt" if prompt_count == 1 else f"prompt_{prompt_count}"
                default = "一只橙色的猫坐在窗边，柔和的自然光，细节清晰。" if prompt_count == 1 else ""
                node["inputs"][key] = default
                fields.append({"id": field_id, "label": "提示词" if prompt_count == 1 else "附加提示词", "kind": "text", "group": "prompt", "default": default, "required": prompt_count == 1, "maxLength": 4000, "binds": [[node_id, key]]})
            elif key in {"unet_name", "ckpt_name", "vae_name", "lora_name"}:
                field_id = f"{key}_{node_id}"
                label = {"unet_name": "模型", "ckpt_name": "模型", "vae_name": "VAE", "lora_name": "LoRA"}[key]
                group = "lora" if key == "lora_name" else "model"
                fields.append({"id": field_id, "label": label, "kind": "choice", "group": group, "default": "current", "options": [{"id": "current", "label": Path(str(value)).name}], "mapping": {"current": value}, "binds": [[node_id, key]]})
            elif key in {"width", "height", "steps", "length", "batch_size", "seed", "noise_seed", "cfg", "denoise", "strength_model", "strength_clip", "fps"}:
                canonical = "seed" if key in {"seed", "noise_seed"} else key
                if canonical in {"strength_model", "strength_clip"}:
                    canonical = "lora_strength_" + node_id
                grouped.setdefault(canonical, []).append((node_id, key, value))
    for key, bindings in grouped.items():
        original = bindings[0][2]
        numeric = {
            "width": ("宽度", "int", 256, 1536, 32, 768),
            "height": ("高度", "int", 256, 1536, 32, 1024),
            "steps": ("采样步数", "int", 1, 40, 1, min(int(original), 20)),
            "length": ("视频帧数", "int", 5, 260, 17, 124),
            "batch_size": ("生成数量", "int", 1, 4, 1, 1),
            "seed": ("种子（-1 为随机）", "int", -1, 2147483647, 1, -1),
            "cfg": ("提示词引导", "float", 1, 12, 0.1, float(original)),
            "denoise": ("重绘幅度", "float", 0.05, 1, 0.05, float(original)),
            "fps": ("视频帧率", "int", 24, 24, 1, 24),
        }
        if key.startswith("lora_strength"):
            label, kind, low, high, step, default = ("LoRA 强度（0 为关闭）", "float", 0, 1.5, 0.05, 0)
        elif key in numeric:
            label, kind, low, high, step, default = numeric[key]
        else:
            continue
        fields.append({"id": key, "label": label, "kind": kind, "group": "lora" if key.startswith("lora_") else "advanced", "min": low, "max": high, "step": step, "default": default, "binds": [[a, b] for a, b, _ in bindings]})
    if mode.endswith("v"):
        for f in fields:
            if f["id"] in {"width", "height"}:
                f["default"] = 384 if f["id"] == "width" else 512
                f["max"] = 1024
    for node_id in image_nodes:
        api[node_id]["inputs"]["image"] = "toolcase-reference.jpg"
    for node_id in output_nodes:
        api[node_id]["inputs"]["filename_prefix"] = "Toolcase/result"
    return {"id": template_id, "name": name, "mode": mode, "description": "来自本机已配置的工作流；模型配套参数固定，新增组合需在电脑端审核。", "requiresImage": mode.startswith("i"), "maxPixels": 1024 * 1024 if mode.endswith("v") else 1536 * 1536, "fields": fields, "imageNodes": image_nodes, "outputNodes": output_nodes, "workflow": api}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--id", required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--mode", choices=["t2i", "i2i", "t2v", "i2v"], required=True)
    parser.add_argument("--comfy", default="http://127.0.0.1:8188")
    args = parser.parse_args()
    graph = json.loads(Path(args.source).read_text(encoding="utf-8-sig"))
    names = {n["type"] for n in graph.get("nodes", []) if n["type"] not in {"Note", "MarkdownNote"}}
    info = {}
    with httpx.Client(timeout=30, trust_env=False) as client:
        for name in names:
            response = client.get(args.comfy.rstrip("/") + "/object_info/" + name)
            response.raise_for_status()
            info.update(response.json())
    api = graph_to_api(graph, info)
    manifest = make_manifest(api, args.id, args.name, args.mode)
    target = Path(args.out)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"已导入 {args.id}；仅开放当前工作流中的模型组合。")


if __name__ == "__main__":
    main()
