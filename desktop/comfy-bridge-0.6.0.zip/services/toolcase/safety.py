"""Local executor rules. Remote credentials never authorize host administration.

These checks are an application boundary, not an OS sandbox for Python/CUDA.
"""
import hashlib
import io
import json
import re

import PIL
from PIL import Image, ImageOps

MAX_JOB_BYTES = 256000
MAX_REFERENCE = 20 * 1024 * 1024


def require_supported_runtime():
    version = re.match(r"^(\d+)\.(\d+)\.(\d+)", PIL.__version__)
    if not version or tuple(map(int, version.groups())) < (12, 3, 0):
        raise RuntimeError("图片解析库版本过旧，拒绝启动公网服务；请使用工具匣 .venv 并安装最新 services/requirements.txt")


def job_identifier(value):
    if not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{32}", value):
        raise ValueError("任务编号不合法")
    return value


def validate_task(job):
    if not isinstance(job, dict):
        raise ValueError("任务必须是对象")
    job_id = job_identifier(job.get("id"))
    payload = job.get("payload")
    if not isinstance(payload, dict):
        raise ValueError("任务参数必须是对象")
    reference = payload.get("inputId")
    if reference is not None and (not isinstance(reference, str) or not re.fullmatch(r"[0-9a-f]{32}", reference)):
        raise ValueError("参考图编号不合法")
    if set(payload) - {"requestId", "worker", "template", "values", "inputId", "workflow"}:
        raise ValueError("电脑只接受生成参数，不接受命令、地址或其他操作")
    if not isinstance(payload.get("template"), str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,80}", payload["template"]):
        raise ValueError("工作流编号不合法")
    if not isinstance(payload.get("values"), dict) or type(job.get("cancel")) is not bool:
        raise ValueError("任务参数或取消状态不合法")
    custom = payload.get("workflow")
    if custom is not None:
        if not isinstance(custom, dict) or set(custom) != {"graph", "mode", "name"}:
            raise ValueError("自定义工作流只能包含节点、名称和模式")
        if not isinstance(custom["mode"], str) or custom["mode"] not in {"t2i", "i2i", "t2v", "i2v"}:
            raise ValueError("生成模式不合法")
    try:
        encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")
    except (ValueError, TypeError, RecursionError) as exc:
        raise ValueError("生成参数不是有效 JSON") from exc
    if len(encoded) > MAX_JOB_BYTES:
        raise ValueError("生成参数超过电脑端大小限制")
    return job_id, payload, hashlib.sha256(encoded).hexdigest()


def model_filename(value, field):
    """Only data-only weight formats; a catalog entry is not a path permission."""
    if field == "vae_name" and value == "pixel_space":
        return True
    if not isinstance(value, str) or not 1 <= len(value) <= 240:
        return False
    path = value.replace("\\", "/")
    if path.startswith("/") or any(c in path for c in ':\x00<>"|?*') or any(ord(c) < 32 for c in path):
        return False
    if any(part in {"", ".", ".."} or part.endswith((".", " ")) for part in path.split("/")):
        return False
    # Avoid pickle-based .pt/.pth/.ckpt/.bin, including implicit approximate VAE aliases.
    return path.lower().endswith((".safetensors", ".gguf"))


def clean_reference(data):
    if len(data) > MAX_REFERENCE:
        raise ValueError("参考图超过电脑端大小限制")
    with Image.open(io.BytesIO(data), formats=["JPEG", "PNG", "WEBP"]) as img:
        if img.format not in {"JPEG", "PNG", "WEBP"} or img.width * img.height > 20_000_000 or getattr(img, "n_frames", 1) != 1:
            raise ValueError("只接受不超过 2000 万像素的静态参考图")
        img.load()
        clean = ImageOps.exif_transpose(img).convert("RGB")
        output = io.BytesIO()
        clean.save(output, "JPEG", quality=95)
    if output.tell() > MAX_REFERENCE:
        raise ValueError("重编码后的参考图过大")
    return output.getvalue()


def own_output(item, job_id):
    job_identifier(job_id)
    name = item.get("filename")
    if (item.get("type") != "output" or item.get("subfolder", "").replace("\\", "/") != "Toolcase"
            or not isinstance(name, str) or not re.fullmatch(re.escape(job_id) + r"_[0-9_]+\.(?:png|jpg|jpeg|webp|gif|mp4|webm)", name)):
        raise ValueError("拒绝回传不属于当前任务的文件")
    return item


def bounded_json(client, method, path, limit=1000000, **kwargs):
    """Bound even a compromised broker's response before parsing it."""
    with client.stream(method, path, **kwargs) as response:
        response.raise_for_status()
        data = bytearray()
        for chunk in response.iter_bytes(65536):
            data.extend(chunk)
            if len(data) > limit:
                raise ValueError("任务站响应超过电脑端大小限制")
    try:
        return json.loads(data)
    except (ValueError, RecursionError) as exc:
        raise ValueError("任务站返回了无效 JSON") from exc
