"""Pair a PC worker without putting credentials in command line history."""
import argparse
import getpass
import json
from pathlib import Path

import httpx

from .agent import validate_server_url


def main():
    parser = argparse.ArgumentParser(description="配对工具匣电脑执行器")
    parser.add_argument("--server", required=True)
    parser.add_argument("--out", default="agent-config.json")
    parser.add_argument("--templates", default="templates")
    parser.add_argument("--allow-local-http", action="store_true")
    args = parser.parse_args()
    server = validate_server_url(args.server, args.allow_local_http)
    target = Path(args.out).resolve()
    if target.exists():
        raise SystemExit("配置文件已存在；请使用新的文件名，避免覆盖现有配对。")
    code = getpass.getpass("输入服务器生成的 worker 配对码（隐藏输入）：").strip()
    with httpx.Client(timeout=30, follow_redirects=False, trust_env=False) as client:
        response = client.post(server + "/v1/pair", json={"code": code, "name": "我的 ComfyUI 电脑"})
        response.raise_for_status()
        pair = response.json()
    if pair["role"] != "worker":
        raise SystemExit("此配对码不是 worker 类型，请撤销误配设备后重新生成。")
    config = {"server": server, "token": pair["token"], "deviceId": pair["deviceId"],
              "comfy": "http://127.0.0.1:8188", "templates": args.templates,
              "allowLocalHttp": args.allow_local_http}
    with target.open("x", encoding="utf-8") as output:
        json.dump(config, output, indent=2)
    target.chmod(0o600)
    print("电脑配对完成。配置包含设备凭据，请保留在当前 Windows 账户的私人目录。")


if __name__ == "__main__":
    main()
