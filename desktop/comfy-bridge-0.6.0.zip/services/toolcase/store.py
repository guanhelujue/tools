import hashlib
import hmac
import json
import math
import secrets
import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path


def digest(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


class Store:
    def __init__(self, directory):
        self.root = Path(directory).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        (self.root / "files").mkdir(exist_ok=True)
        self.path = self.root / "broker.sqlite3"
        with self.db() as db:
            db.executescript("""
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS devices(id TEXT PRIMARY KEY, role TEXT NOT NULL, name TEXT NOT NULL,
                    token_hash TEXT UNIQUE NOT NULL, created REAL NOT NULL, revoked INTEGER NOT NULL DEFAULT 0);
                CREATE TABLE IF NOT EXISTS pairing(code_hash TEXT PRIMARY KEY, role TEXT NOT NULL, expires REAL NOT NULL);
                CREATE TABLE IF NOT EXISTS catalogs(worker TEXT PRIMARY KEY, payload TEXT NOT NULL, seen REAL NOT NULL);
                CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY, request_id TEXT UNIQUE NOT NULL, requester TEXT NOT NULL,
                    worker TEXT NOT NULL, template TEXT NOT NULL, payload TEXT NOT NULL, state TEXT NOT NULL,
                    message TEXT NOT NULL, created REAL NOT NULL, updated REAL NOT NULL, cancel INTEGER NOT NULL DEFAULT 0);
                CREATE TABLE IF NOT EXISTS files(id TEXT PRIMARY KEY, job TEXT, requester TEXT NOT NULL,
                    name TEXT NOT NULL, mime TEXT NOT NULL, size INTEGER NOT NULL, created REAL NOT NULL);
                CREATE TABLE IF NOT EXISTS mobile_access(id INTEGER PRIMARY KEY CHECK(id=1),
                    salt TEXT NOT NULL, password_hash TEXT NOT NULL, device_id TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS mobile_sessions(token_hash TEXT PRIMARY KEY,
                    device_id TEXT NOT NULL, created REAL NOT NULL, expires REAL NOT NULL);
                CREATE TABLE IF NOT EXISTS login_limit(id INTEGER PRIMARY KEY CHECK(id=1),
                    window_start REAL NOT NULL, failures INTEGER NOT NULL);
            """)
            # Both local/public listeners may start together against an older database.
            db.execute('BEGIN IMMEDIATE')
            if 'deleted' not in {row['name'] for row in db.execute('PRAGMA table_info(jobs)')}:
                db.execute('ALTER TABLE jobs ADD COLUMN deleted INTEGER NOT NULL DEFAULT 0')

    @contextmanager
    def db(self):
        connection = sqlite3.connect(self.path, timeout=30)
        connection.row_factory = sqlite3.Row
        try:
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def create_pairing(self, role: str, minutes=10) -> str:
        if role not in {"mobile", "worker"}:
            raise ValueError("role must be mobile or worker")
        code = secrets.token_hex(12).upper()
        with self.db() as db:
            db.execute("INSERT INTO pairing VALUES(?,?,?)", (digest(code), role, time.time() + minutes * 60))
        return code

    def pair(self, code: str, name: str, required_role=None):
        token = secrets.token_urlsafe(32)
        device_id = secrets.token_hex(12)
        with self.db() as db:
            db.execute("BEGIN IMMEDIATE")
            pair = db.execute("SELECT * FROM pairing WHERE code_hash=?", (digest(code.strip().upper()),)).fetchone()
            if not pair or pair["expires"] < time.time() or (required_role and pair["role"] != required_role):
                return None
            if pair["role"] == "mobile" and db.execute("SELECT 1 FROM mobile_access").fetchone():
                return None
            db.execute("DELETE FROM pairing WHERE code_hash=?", (pair["code_hash"],))
            db.execute("INSERT INTO devices(id,role,name,token_hash,created) VALUES(?,?,?,?,?)",
                       (device_id, pair["role"], name, digest(token), time.time()))
        return {"token": token, "deviceId": device_id, "role": pair["role"]}

    def authenticate(self, token):
        with self.db() as db:
            row = db.execute("SELECT id,role,name FROM devices WHERE token_hash=? AND revoked=0", (digest(token),)).fetchone()
            if not row:
                row = db.execute("SELECT d.id,d.role,d.name FROM mobile_sessions s JOIN devices d ON d.id=s.device_id WHERE s.token_hash=? AND s.expires>? AND d.revoked=0", (digest(token), time.time())).fetchone()
            return dict(row) if row else None

    def revoke(self, device_id):
        with self.db() as db:
            db.execute("UPDATE devices SET revoked=1 WHERE id=?", (device_id,))
            db.execute("DELETE FROM mobile_sessions WHERE device_id=?", (device_id,))
            db.execute("UPDATE jobs SET cancel=1,state=CASE WHEN state='queued' THEN 'cancelled' ELSE state END,updated=? WHERE requester=? AND state NOT IN ('completed','failed','cancelled')", (time.time(), device_id))

    @staticmethod
    def password_hash(password, salt):
        # OWASP scrypt baseline; hashes only, never plaintext or an APK-wide secret.
        return hashlib.scrypt(password.encode('utf-8'), salt=bytes.fromhex(salt),
                              n=2**17, r=8, p=1, maxmem=256*1024*1024).hex()

    def has_access_password(self):
        with self.db() as db:
            return db.execute("SELECT 1 FROM mobile_access").fetchone() is not None

    def set_access_password(self, password):
        if not 8 <= len(password) <= 128 or not password.strip():
            raise ValueError('访问口令需要 8–128 个字符')
        salt = secrets.token_hex(16)
        hashed = self.password_hash(password, salt)
        with self.db() as db:
            db.execute('BEGIN IMMEDIATE')
            previous = db.execute('SELECT device_id FROM mobile_access').fetchone()
            device_id = previous['device_id'] if previous else secrets.token_hex(12)
            db.execute("UPDATE devices SET revoked=1 WHERE role='mobile'")
            db.execute('DELETE FROM mobile_sessions')
            db.execute("DELETE FROM pairing WHERE role='mobile'")
            db.execute('DELETE FROM login_limit')
            if not previous:
                # This legacy token is random and discarded: only password sessions can use this identity.
                db.execute('INSERT INTO devices(id,role,name,token_hash,created) VALUES(?,?,?,?,?)',
                           (device_id, 'mobile', '个人手机', digest(secrets.token_urlsafe(32)), time.time()))
            db.execute('INSERT INTO mobile_access VALUES(1,?,?,?) ON CONFLICT(id) DO UPDATE SET salt=excluded.salt,password_hash=excluded.password_hash',
                       (salt, hashed, device_id))

    def login(self, password):
        """One personal account, independent revocable sessions; global persistent guessing limit.

        Returns (credentials, retry_after). The transaction also serializes KDF work across listeners.
        Never trust X-Forwarded-For to allocate a fresh guessing budget.
        """
        with self.db() as db:
            db.execute('BEGIN IMMEDIATE')
            now = time.time()
            limit = db.execute('SELECT * FROM login_limit WHERE id=1').fetchone()
            if not limit or now >= limit['window_start'] + 900:
                db.execute('INSERT OR REPLACE INTO login_limit VALUES(1,?,0)', (now,))
                limit = {'window_start': now, 'failures': 0}
            if limit['failures'] >= 5:
                return None, max(1, math.ceil(limit['window_start'] + 900 - now))
            access = db.execute('SELECT * FROM mobile_access WHERE id=1').fetchone()
            valid = (access is not None and 1 <= len(password) <= 128 and
                     hmac.compare_digest(self.password_hash(password, access['salt']), access['password_hash']))
            if not valid:
                db.execute('UPDATE login_limit SET failures=failures+1 WHERE id=1')
                return None, 0
            db.execute('UPDATE login_limit SET failures=0,window_start=? WHERE id=1', (now,))
            db.execute('UPDATE devices SET revoked=0 WHERE id=?', (access['device_id'],))
            db.execute('DELETE FROM mobile_sessions WHERE expires<=?', (now,))
            # Bound storage while allowing several of the owner's phones to stay connected.
            db.execute('DELETE FROM mobile_sessions WHERE token_hash IN (SELECT token_hash FROM mobile_sessions ORDER BY created DESC LIMIT -1 OFFSET 19)')
            token = secrets.token_urlsafe(32)
            expires = now + 7 * 86400
            db.execute('INSERT INTO mobile_sessions VALUES(?,?,?,?)', (digest(token), access['device_id'], now, expires))
            return {'token': token, 'deviceId': access['device_id'], 'role': 'mobile', 'expiresAt': expires}, 0

    def logout(self, token):
        with self.db() as db:
            db.execute('DELETE FROM mobile_sessions WHERE token_hash=?', (digest(token),))


def job_json(db, row):
    job = dict(row)
    job["payload"] = json.loads(job["payload"])
    job["cancel"] = bool(job["cancel"])
    job["artifacts"] = [dict(a) for a in db.execute("SELECT id,name,mime,size FROM files WHERE job=? ORDER BY created", (job["id"],))]
    return job
