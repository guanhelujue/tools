"""Read saved ComfyUI workflows through the loopback user-data API, without editing them."""
import copy
import hashlib
import json
import time
from pathlib import PurePosixPath
from urllib.parse import quote

import httpx

from .workflows import node_catalog, prepare_workflow


def saved_graph_to_api(source, info):
    source = source.get("prompt", source)
    if "nodes" not in source:
        return copy.deepcopy(source)
    if not isinstance(source["nodes"], list) or len(source["nodes"]) > 160:
        raise ValueError("工作流节点过多，请使用精简的生成工作流")
    links = {}
    for link in source.get("links", []):
        if isinstance(link, list) and len(link) >= 6:
            links[link[0]] = [str(link[1]), link[2]]
        elif isinstance(link, dict):
            links[link["id"]] = [str(link["origin_id"]), link["origin_slot"]]
        else:
            raise ValueError("画布连线格式尚不支持，请在电脑另存为 API JSON")
    nodes = node_catalog(info)
    graph = {}
    for node in source["nodes"]:
        kind, node_id = node["type"], str(node["id"])
        if kind in {"Note", "MarkdownNote"}:
            continue
        if node_id in graph:
            raise ValueError("画布节点编号重复")
        if kind not in nodes:
            raise ValueError(f"{kind} 尚未支持远程运行")
        if node.get("mode", 0) != 0:
            raise ValueError(f"节点 {node_id} 使用旁路或停用模式，请另存为 API JSON")
        schema = nodes[kind]
        if not schema["uiImportSupported"]:
            raise ValueError(f"{kind} 使用动态控件，请另存为 API JSON")
        inputs = {}
        for slot in node.get("inputs", []):
            if slot.get("link") is not None:
                if slot["link"] not in links:
                    raise ValueError(f"节点 {node_id} 的连线缺失")
                inputs[slot["name"]] = copy.deepcopy(links[slot["link"]])
        specs = schema["inputs"]
        # File paths are supplied by the existing reference/output handling.
        if kind in {"LoadImage", "SaveVideo"}:
            inputs.update({key: spec["default"] for key, spec in specs.items() if spec.get("locked")})
        else:
            widgets = node.get("widgets_values", [])
            if not isinstance(widgets, list):
                raise ValueError(f"{kind} 的控件格式尚不支持")
            position = 0
            for key in schema["inputOrder"]:
                spec = specs[key]
                if spec["kind"] not in {"INT", "FLOAT", "STRING", "BOOLEAN", "CHOICE"} or spec.get("forceInput"):
                    continue
                if key in inputs:
                    raise ValueError(f"节点 {node_id}.{key} 将控件转成了输入，请另存为 API JSON")
                if position < len(widgets):
                    inputs[key] = widgets[position]
                    position += 1
                    if spec.get("controlAfterGenerate") and position < len(widgets) and isinstance(widgets[position], str) and widgets[position] in {"fixed", "randomize", "increment", "decrement"}:
                        position += 1
                elif "default" in spec:
                    inputs[key] = spec["default"]
                elif spec.get("required"):
                    raise ValueError(f"节点 {node_id}.{key} 缺少值")
            if position != len(widgets):
                raise ValueError(f"{kind} 有无法确认的控件，请另存为 API JSON")
        graph[node_id] = {"class_type": kind, "inputs": inputs, "_meta": {"title": node.get("title", kind)}}
    return graph


class DesktopWorkflows:
    def __init__(self, client):
        self.client = client
        self.cache = {}
        self.checked_at = 0
        self.sources = []
        self.errors = []

    def scan(self, info, force=False):
        if not force and time.monotonic() - self.checked_at < 30:
            return self.sources, self.errors
        sources, errors, cache = [], [], {}
        try:
            response = self.client.get("/userdata", params={"dir": "workflows", "recurse": "true", "full_info": "true"}, timeout=5)
            if response.status_code == 404:
                self.sources, self.errors, self.cache = [], [], {}
                self.checked_at = time.monotonic()
                return [], []
            response.raise_for_status()
            entries = response.json()
            if not isinstance(entries, list) or any(not isinstance(entry, dict) or not isinstance(entry.get("path"), str) for entry in entries):
                raise ValueError("工作流目录响应格式不正确")
            for entry in sorted(entries, key=lambda item: str(item.get("path", "")))[:80]:
                path = entry.get("path", "")
                relative = PurePosixPath(path)
                if not path.endswith(".json") or relative.is_absolute() or ".." in relative.parts or "\\" in path or ":" in path:
                    continue
                name = str(relative.with_suffix(""))[:80]
                try:
                    if entry.get("size", 0) > 512 * 1024:
                        raise ValueError("工作流文件超过 512 KiB，请在电脑精简后保存")
                    stamp = (entry.get("modified"), entry.get("size"))
                    previous = self.cache.get(path)
                    if previous and previous[0] == stamp:
                        raw = previous[1]
                    else:
                        with self.client.stream("GET", "/userdata/" + quote("workflows/" + path, safe=""), timeout=5) as stream:
                            stream.raise_for_status()
                            data = bytearray()
                            for chunk in stream.iter_bytes():
                                data.extend(chunk)
                                if len(data) > 512 * 1024:
                                    raise ValueError("工作流文件超过 512 KiB")
                        raw = json.loads(data.decode("utf-8-sig"))
                    cache[path] = (stamp, raw)
                    graph = saved_graph_to_api(raw, info)
                    kinds = {node["class_type"] for node in graph.values()}
                    mode = ("i" if "LoadImage" in kinds else "t") + "2" + ("v" if "SaveVideo" in kinds else "i")
                    template_id = "desktop-" + hashlib.sha256(path.encode()).hexdigest()[:24]
                    # Keep precisely the values saved on the computer; no example prompt substitution.
                    template = prepare_workflow(graph, node_catalog(info), name, mode, template_id)
                    template.update(source="computer", sourceFile=path, description="来自电脑 ComfyUI 已保存的工作流；运行不修改原文件")
                    sources.append(template)
                except (ValueError, KeyError, TypeError, httpx.HTTPError) as exc:
                    errors.append({"name": name, "source": "computer", "reason": str(exc)[:250]})
            if len(entries) > 80:
                errors.append({"name": "电脑工作流", "source": "computer", "reason": "最多读取前 80 个文件，请在电脑整理目录"})
        except (ValueError, KeyError, TypeError, httpx.HTTPError):
            # A failed refresh must not present stale files as newly synchronized.
            errors.append({"name": "电脑工作流", "source": "computer", "reason": "暂时无法读取 ComfyUI 保存目录，稍后会自动重试"})
        self.sources, self.errors, self.cache = sources, errors, cache
        self.checked_at = time.monotonic()
        return sources, errors
