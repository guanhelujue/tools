import copy
import json
import secrets
from pathlib import Path, PurePosixPath

from .contracts import validate_values
from .workflows import prepare_workflow, public_template, compile_workflow, node_catalog


class TemplateRegistry:
    def __init__(self, directory):
        self.directory = Path(directory).resolve()
        self.templates = {}
        self.live = False
        for path in sorted(self.directory.glob("*.json")):
            template = json.loads(path.read_text(encoding="utf-8"))
            if "workflow" in template and "fields" in template:
                self.templates[template["id"]] = template

    def refresh(self, info, saved_sources=(), saved_errors=()):
        nodes = node_catalog(info)
        templates = {}
        errors = list(saved_errors)
        paths = sorted(self.directory.glob("*.json")) + sorted((self.directory.parent / "recipes").glob("*.json"))
        for path in paths:
            source = json.loads(path.read_text(encoding="utf-8"))
            try:
                template = prepare_workflow(source["workflow"], nodes, source["name"], source["mode"], source["id"])
                templates[template["id"]] = template
            except (KeyError, ValueError, TypeError) as exc:
                errors.append({"name": source.get("name", path.stem), "reason": str(exc)[:250]})
        size = len(json.dumps([public_template(t) for t in templates.values()], ensure_ascii=False))
        for template in saved_sources:
            extra = len(json.dumps(public_template(template), ensure_ascii=False))
            if len(templates) >= 40 or size + extra > 650000:
                errors.append({"name": template["name"], "source": "computer", "reason": "手机目录容量已满，请精简电脑工作流"})
                continue
            templates[template["id"]] = template
            size += extra
        self.templates = templates
        self.live = True
        return errors

    def catalog(self):
        if self.live:
            return [public_template(t) for t in self.templates.values()]
        result = []
        for template in self.templates.values():
            public = {key: template[key] for key in ("id", "name", "mode", "description", "requiresImage", "maxPixels")}
            public["fields"] = [{key: value for key, value in field.items() if key not in {"binds", "mapping"}} for field in template["fields"]]
            result.append(public)
        return result

    def compile(self, template_id, values, reference=None, job_id="test"):
        if template_id not in self.templates:
            raise ValueError("工作流未获本机授权")
        template = self.templates[template_id]
        if self.live:
            return compile_workflow(template, values, reference, job_id)
        normalized = validate_values(template, values)
        workflow = copy.deepcopy(template["workflow"])
        if template["requiresImage"] and not reference:
            raise ValueError("此工作流需要参考图")
        for field in template["fields"]:
            value = normalized[field["id"]]
            if field["kind"] == "choice":
                value = field["mapping"][value]
            if field["id"] == "seed" and value == -1:
                value = secrets.randbelow(2**31 - 1)
            for node_id, input_name in field["binds"]:
                if node_id not in workflow or input_name not in workflow[node_id]["inputs"]:
                    raise ValueError("本机工作流映射已失效")
                workflow[node_id]["inputs"][input_name] = value
        for node_id in template.get("imageNodes", []):
            workflow[node_id]["inputs"]["image"] = reference
        for node_id in template["outputNodes"]:
            workflow[node_id]["inputs"]["filename_prefix"] = "Toolcase/" + job_id
        return workflow

    def outputs(self, template_id, history):
        return self.outputs_for(self.templates[template_id]["outputNodes"], history)

    @staticmethod
    def outputs_for(output_nodes, history):
        outputs = []
        for node_id in output_nodes:
            node = history.get("outputs", {}).get(node_id, {})
            for key in ("images", "gifs", "videos"):
                for artifact in node.get(key, []):
                    filename = artifact.get("filename", "")
                    subfolder = artifact.get("subfolder", "").replace("\\", "/")
                    if not filename or "/" in filename or "\\" in filename or ":" in filename or filename in {".", ".."}:
                        raise ValueError("成品文件名不安全")
                    if PurePosixPath(subfolder).is_absolute() or ".." in PurePosixPath(subfolder).parts or ":" in subfolder:
                        raise ValueError("成品目录不安全")
                    if artifact.get("type", "output") != "output":
                        continue
                    if Path(filename).suffix.lower() not in {".png", ".jpg", ".jpeg", ".webp", ".gif", ".mp4", ".webm"}:
                        continue
                    item = {"filename": filename, "subfolder": subfolder, "type": "output"}
                    if item not in outputs:
                        outputs.append(item)
        return outputs[:8]
