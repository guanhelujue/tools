"""Authenticated mobile sharing through a hosted SSH tunnel."""
import argparse
import getpass
import json
import os
import queue
import re
import shutil
import socket
import subprocess
import sys
import threading
import time
from pathlib import Path

import httpx

from .store import Store
from .safety import bounded_json


def parse_tunnel_url(line):
    try:
        event = json.loads(line)
    except (ValueError, TypeError):
        return None
    if event.get('type') != 'v1.tcpip_forward.register.accepted':
        return None
    host = event.get('id', '').removeprefix('localhost/')
    if not re.fullmatch(r'[a-z0-9-]+\.(?:lhr\.life|localhost\.run)', host):
        return None
    url = 'https://' + host
    return url if url in event.get('data', '') else None


def tunnel_command(ssh, root, mobile_port=8788, *, anonymous=False):
    return [ssh, '-F', os.devnull, '-T', '-i', str(root / 'identity'),
            '-o', 'IdentitiesOnly=yes', '-o', 'IdentityAgent=none', '-o', 'BatchMode=yes',
            '-o', 'ForwardAgent=no', '-o', 'ForwardX11=no', '-o', 'PermitLocalCommand=no',
            '-o', 'EscapeChar=none',
            # OpenSSH parses -o values again; argv quoting alone does not protect spaces.
            '-o', 'StrictHostKeyChecking=accept-new', '-o', 'UserKnownHostsFile="' + (root / 'known_hosts').as_posix() + '"',
            '-o', 'ExitOnForwardFailure=yes', '-o', 'ConnectTimeout=15',
            '-o', 'ServerAliveInterval=30', '-o', 'ServerAliveCountMax=3',
            '-R', f'80:127.0.0.1:{mobile_port}',
            ('nokey' if anonymous else 'toolcase') + '@localhost.run', '--', '--output', 'json']


def end_process(process):
    if process.poll() is None:
        if os.name == 'nt':
            # Windows venv Python launchers create a second Python process.
            # Close this owned tree, so stopping sharing cannot leave listeners alive.
            subprocess.run([str(Path(os.environ['SystemRoot']) / 'System32' / 'taskkill.exe'),
                            '/PID', str(process.pid), '/T', '/F'], stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL, timeout=10, creationflags=subprocess.CREATE_NO_WINDOW)
            process.wait(timeout=5)
            return
        process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=5)


def connect_tunnel(command, env, flags, stopping, timeout=45):
    """Keep draining provider output; callers own and must close the returned process."""
    process = subprocess.Popen(command, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                               text=True, encoding='utf-8', errors='replace', creationflags=flags)
    lines = queue.Queue(maxsize=100)
    def read_output():
        for line in process.stdout:
            try:
                lines.put_nowait(line)
            except queue.Full:
                pass
    threading.Thread(target=read_output, daemon=True).start()
    deadline = time.monotonic() + timeout
    try:
        while time.monotonic() < deadline and process.poll() is None and not stopping():
            try:
                line = lines.get(timeout=0.5)
            except queue.Empty:
                continue
            url = parse_tunnel_url(line)
            if url:
                return process, url
        end_process(process)
        return None, None
    except BaseException:
        end_process(process)
        raise


def tunnel_healthy(url):
    try:
        with httpx.Client(trust_env=False, timeout=5, follow_redirects=False) as client:
            result = bounded_json(client, 'GET', url + '/health', limit=16000)
            return isinstance(result, dict) and result.get('service') == 'toolcase'
    except (httpx.HTTPError, ValueError):
        return False


def main():
    parser = argparse.ArgumentParser(description='内网穿透：手机使用固定访问口令登录；Ctrl+C 停止并撤销本次手机会话。')
    parser.add_argument('--data', default='../.local-share')
    parser.add_argument('--templates', default='templates')
    parser.add_argument('--local-port', type=int, default=8787)
    parser.add_argument('--mobile-port', type=int, default=8788)
    parser.add_argument('--duration', type=int, default=0, help='运行秒数；0 表示持续运行直到手动停止，正数用于限时联调')
    parser.add_argument('--set-password', action='store_true', help='在电脑端更改访问口令（隐藏输入）')
    parser.add_argument('--stop', action='store_true', help='停止此数据目录正在运行的连接')
    parser.add_argument('--anonymous', action='store_true', help='未登记 SSH 公钥时使用匿名隧道；重连可能改变地址')
    args = parser.parse_args()
    if args.duration < 0 or args.local_port == args.mobile_port or not all(1024 <= p <= 65535 for p in (args.local_port,args.mobile_port)):
        raise SystemExit('需要不同的 1024–65535 端口，运行时长为 0（不限时）或正整数。')
    root = Path(args.data).resolve()
    stop_file = root / 'stop.request'
    if args.stop:
        if root.exists():
            stop_file.touch()
        print('已请求停止电脑连接。')
        return
    templates = Path(args.templates).resolve()
    if not list(templates.glob('*.json')):
        raise SystemExit('未找到工作流模板，请在 services 目录运行，或指定 --templates。')
    ssh, keygen = shutil.which('ssh'), shutil.which('ssh-keygen')
    if not ssh or not keygen:
        raise SystemExit('需要系统 OpenSSH 客户端（ssh 和 ssh-keygen）。')
    for port in (args.local_port, args.mobile_port):
        with socket.socket() as probe:
            try:
                probe.bind(('127.0.0.1', port))
            except OSError as exc:
                raise SystemExit(f'本机 {port} 端口已被占用，请先关闭先前的工具匣服务。') from exc
    root.mkdir(parents=True, exist_ok=True)
    stop_file.unlink(missing_ok=True)
    if not (root / 'identity').exists():
        subprocess.run([keygen, '-t', 'ed25519', '-f', str(root / 'identity'), '-N', '', '-C', 'toolcase-tunnel'], check=True, stdout=subprocess.DEVNULL)
    if args.anonymous:
        print('SSH 使用匿名模式，重连可能更换公网地址。', flush=True)
    else:
        print('SSH 使用密钥认证。请先在 https://admin.localhost.run/ 登记公钥：' + str(root / 'identity.pub'), flush=True)
    store = Store(root / 'data')
    if args.set_password or not store.has_access_password():
        password = getpass.getpass('设置手机访问口令（至少 8 位，建议更长）：')
        if password != getpass.getpass('再次输入：'):
            raise SystemExit('两次口令不一致，未启动分享。')
        store.set_access_password(password)
        del password
    # Free tunnel addresses rotate. Do not leave reusable mobile credentials alive between sessions.
    def revoke_mobiles():
        with store.db() as db:
            ids = [r[0] for r in db.execute("SELECT id FROM devices WHERE role='mobile' AND revoked=0")]
        for device_id in ids:
            store.revoke(device_id)
    revoke_mobiles()
    config_file = root / 'agent.json'
    config = json.loads(config_file.read_text()) if config_file.exists() else None
    if not config or not store.authenticate(config['token']):
        worker = store.pair(store.create_pairing('worker'), '我的 ComfyUI 电脑')
        config = {'token': worker['token']}
    config.update(server=f'http://127.0.0.1:{args.local_port}', comfy='http://127.0.0.1:8188',
                  allowLocalHttp=True, templates=str(templates))
    config_file.write_text(json.dumps(config), encoding='utf-8')
    config_file.chmod(0o600)
    processes, logs = [], []
    env = {**os.environ, 'TOOLCASE_DATA': str(store.root), 'PYTHONUTF8': '1'}
    flags = subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
    def start(arguments, name):
        log = (root / (name + '.log')).open('w', encoding='utf-8')
        logs.append(log)
        process = subprocess.Popen(arguments, env=env, stdout=log, stderr=subprocess.STDOUT, creationflags=flags)
        processes.append(process)
        return process
    try:
        for factory, port, name in [('create_app', args.local_port, 'local'), ('create_mobile_app', args.mobile_port, 'mobile')]:
            start([sys.executable, '-m', 'uvicorn', 'toolcase.broker:' + factory, '--factory', '--host',
                   '127.0.0.1', '--port', str(port), '--no-access-log', '--limit-concurrency', '16'], name)
        with httpx.Client(trust_env=False, timeout=2) as client:
            for _ in range(30):
                try:
                    if all(client.get(f'http://127.0.0.1:{port}/health').status_code == 200 for port in (args.local_port,args.mobile_port)):
                        break
                except httpx.HTTPError:
                    pass
                time.sleep(0.5)
            else:
                raise RuntimeError('本地服务未能启动，请查看本地日志。')
        start([sys.executable, '-m', 'toolcase.agent', '--config', str(config_file)], 'agent')
        print((f'本次会话最长 {args.duration} 秒。' if args.duration else '已取消一小时自动关闭，持续运行直到手动停止。') + '保留此窗口，Ctrl+C 停止并撤销手机凭据。', flush=True)
        print('App 内可使用固定入口名 guanhelujue；免费隧道的实际网址仍可能变化，入口名不会自动追踪新网址。', flush=True)
        print('HTTPS 由隧道商终止，对方可见传输内容；请先用普通测试素材。', flush=True)
        until = time.monotonic() + args.duration if args.duration else None
        expires = time.time() + args.duration if args.duration else None
        def stopping():
            return stop_file.exists() or (until is not None and time.monotonic() >= until)
        previous_url, retry = None, 2
        while not stopping():
            if any(p.poll() is not None for p in processes):
                raise RuntimeError('本机服务已退出，请查看日志后重新启动。')
            tunnel, url = connect_tunnel(tunnel_command(ssh, root, args.mobile_port, anonymous=args.anonymous), env, flags, stopping)
            if tunnel:
                processes.append(tunnel)
                try:
                    if previous_url and previous_url != url:
                        # An old free hostname could be reassigned. Revoke sessions, without cancelling jobs.
                        with store.db() as db:
                            db.execute('DELETE FROM mobile_sessions')
                        print('隧道实际地址已改变。请在 App「实际地址与重新登录」中更新；入口名和口令不变。', flush=True)
                    previous_url = url
                    print('\n服务器地址：' + url, flush=True)
                    print('手机首次设置：粘贴地址，输入固定访问口令，点击「连接电脑」。连接后仅显示你保存的入口名称。', flush=True)
                    session = {'url':url,'auth':'password','expiresAt':expires,'name':'guanhelujue'}
                    (root / 'current-session.json').write_text(json.dumps(session), encoding='utf-8')
                    retry = 2
                    next_probe, failed_probes = time.monotonic() + 30, 0
                    while not stopping() and tunnel.poll() is None:
                        if any(p is not tunnel and p.poll() is not None for p in processes):
                            raise RuntimeError('本机服务已退出，请查看日志后重新启动。')
                        if time.monotonic() >= next_probe:
                            failed_probes = 0 if tunnel_healthy(url) else failed_probes + 1
                            next_probe = time.monotonic() + 30
                            if failed_probes >= 3:
                                print('公网连续三次不可达，重建隧道；本机任务服务保持运行。', flush=True)
                                break
                        time.sleep(1)
                finally:
                    (root / 'current-session.json').unlink(missing_ok=True)
                    end_process(tunnel)
                    processes.remove(tunnel)
            if stopping():
                break
            print(f'隧道暂时断开，{retry} 秒后自动重试；本机任务服务仍运行。', flush=True)
            resume = time.monotonic() + retry
            while time.monotonic() < resume and not stopping():
                time.sleep(0.5)
            retry = min(retry * 2, 30)
    except KeyboardInterrupt:
        pass
    finally:
        revoke_mobiles()
        with store.db() as db:
            db.execute("DELETE FROM pairing WHERE role='mobile'")
        (root / 'current-session.json').unlink(missing_ok=True)
        stop_file.unlink(missing_ok=True)
        for process in reversed(processes):
            end_process(process)
        for log in logs:
            log.close()
        print('分享已停止，手机凭据已撤销；ComfyUI 本体仍由你自行管理。')


if __name__ == '__main__':
    main()
