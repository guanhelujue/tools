import math
import re

MODES = {"t2i", "i2i", "t2v", "i2v"}
ID_PATTERN = re.compile(r"^[A-Za-z0-9_-]{1,80}$")


def validate_values(template: dict, submitted: dict) -> dict:
    fields = {f["id"]: f for f in template["fields"]}
    if set(submitted) - fields.keys():
        raise ValueError("包含未开放的参数")
    values = {}
    for key, spec in fields.items():
        value = submitted.get(key, spec.get("default"))
        kind = spec["kind"]
        if kind == "text":
            if not isinstance(value, str) or len(value) > spec.get("maxLength", 4000):
                raise ValueError(f"{spec['label']}文本过长或类型错误")
            if spec.get("required") and not value.strip():
                raise ValueError(f"请填写{spec['label']}")
        elif kind == "bool":
            if type(value) is not bool:
                raise ValueError(f"{spec['label']}需要开关值")
        elif kind == "choice":
            if not isinstance(value, str) or value not in {o["id"] for o in spec["options"]}:
                raise ValueError(f"{spec['label']}不在允许的选项中")
        elif kind in {"int", "float"}:
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
                raise ValueError(f"{spec['label']}必须是数字")
            if kind == "int" and value != int(value):
                raise ValueError(f"{spec['label']}必须是整数")
            if not spec["min"] <= value <= spec["max"]:
                raise ValueError(f"{spec['label']}超出范围")
            step = spec.get("step", 1 if kind == "int" else 0)
            if step and abs((value - spec["min"]) / step - round((value - spec["min"]) / step)) > 1e-5:
                raise ValueError(f"{spec['label']}不符合步进要求")
            value = int(value) if kind == "int" else float(value)
        else:
            raise ValueError("未知参数类型")
        values[key] = value
    if values.get("width", 1) * values.get("height", 1) > template.get("maxPixels", 1536 * 1536):
        raise ValueError("画面像素数超过本机上限")
    return values
