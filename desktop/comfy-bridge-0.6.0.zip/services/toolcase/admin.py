import argparse
import getpass
import json
import sys
import time
from pathlib import Path

from .store import Store


def main():
    parser = argparse.ArgumentParser(description="工具匣任务站管理（仅服务器本机使用）")
    parser.add_argument("--data", default=".data")
    subs = parser.add_subparsers(dest="command", required=True)
    pairing = subs.add_parser("pair")
    pairing.add_argument("--role", choices=["mobile", "worker"], required=True)
    pairing.add_argument("--out", required=True, help="配对码写入的本地文件；有效期 10 分钟")
    subs.add_parser("devices")
    password = subs.add_parser("set-password", help="设置或更改手机固定访问口令，立即撤销旧手机会话")
    password.add_argument("--stdin", action="store_true", help="自动化专用：从标准输入读取口令，不通过命令行参数传递")
    revoke = subs.add_parser("revoke")
    revoke.add_argument("device_id")
    purge = subs.add_parser("purge")
    purge.add_argument("--older-than-days", type=int, default=7)
    args = parser.parse_args()
    store = Store(args.data)
    if args.command == "set-password":
        if args.stdin:
            value = sys.stdin.read().rstrip('\r\n')
        else:
            value = getpass.getpass('新访问口令（至少 8 位，建议更长）：')
            if value != getpass.getpass('再次输入：'):
                raise SystemExit('两次口令不一致，未更改。')
        try:
            store.set_access_password(value)
        except ValueError as exc:
            raise SystemExit(str(exc)) from exc
        print('访问口令已设置，仅保存加盐哈希。旧手机会话已撤销；手机下次使用新口令登录。')
    elif args.command == "pair":
        if args.role == 'mobile' and store.has_access_password():
            raise SystemExit('已启用固定口令，手机请使用口令登录；不再生成手机配对码。')
        target = Path(args.out)
        target.write_text(json.dumps({"code": store.create_pairing(args.role), "role": args.role, "expiresInSeconds": 600}, indent=2), encoding="utf-8")
        target.chmod(0o600)
        print("一次性配对码已写入指定文件，有效期 10 分钟。")
    elif args.command == "devices":
        with store.db() as db:
            print(json.dumps([dict(r) for r in db.execute("SELECT id,role,name,revoked FROM devices")], ensure_ascii=False, indent=2))
    elif args.command == "revoke":
        store.revoke(args.device_id)
        print("已撤销设备凭据。")
    elif args.command == "purge":
        if args.older_than_days < 1:
            raise SystemExit("保留天数至少为 1")
        with store.db() as db:
            rows = db.execute("SELECT id FROM files WHERE created<? AND (job IS NULL OR job IN (SELECT id FROM jobs WHERE state IN ('completed','failed','cancelled'))) AND id NOT IN (SELECT json_extract(payload,'$.inputId') FROM jobs WHERE state NOT IN ('completed','failed','cancelled') AND json_extract(payload,'$.inputId') IS NOT NULL)", (time.time() - args.older_than_days * 86400,)).fetchall()
            for row in rows:
                (store.root / "files" / row["id"]).unlink(missing_ok=True)
                db.execute("DELETE FROM files WHERE id=?", (row["id"],))
        print(f"已清理 {len(rows)} 个过期文件。")


if __name__ == "__main__":
    main()
