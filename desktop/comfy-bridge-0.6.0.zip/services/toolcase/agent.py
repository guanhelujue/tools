import argparse
import json
import logging
import mimetypes
import os
import re
import threading
import time
import uuid
from pathlib import Path
from urllib.parse import urlparse

import httpx
from PIL import Image

from .templates import TemplateRegistry
from .desktop_workflows import DesktopWorkflows
from .workflows import node_catalog, inventory_from_info, prepare_workflow, compile_workflow
from .safety import validate_task, job_identifier, clean_reference, own_output, bounded_json, require_supported_runtime

LOG = logging.getLogger("toolcase.agent")


def validate_server_url(value, allow_local=False):
    url = urlparse(value)
    if url.username or url.password or url.query or url.fragment or url.path not in {"", "/"}:
        raise ValueError("服务器地址必须是无账号、路径和查询参数的 HTTPS 根地址")
    if url.scheme == "https" and url.hostname:
        return value.rstrip("/")
    if allow_local and url.scheme == "http" and url.hostname in {"127.0.0.1", "localhost", "::1"}:
        return value.rstrip("/")
    raise ValueError("必须使用 HTTPS；开发模式只允许本机回环 HTTP")


class Agent:
    def __init__(self, config_path):
        require_supported_runtime()
        self.config_path = Path(config_path).resolve()
        self.config = json.loads(self.config_path.read_text(encoding="utf-8"))
        server = validate_server_url(self.config["server"], self.config.get("allowLocalHttp", False))
        comfy = self.config.get("comfy", "http://127.0.0.1:8188").rstrip("/")
        local_url = urlparse(comfy)
        if (local_url.scheme != "http" or local_url.hostname not in {"127.0.0.1", "::1"}
                or local_url.username or local_url.password or local_url.query or local_url.fragment or local_url.path):
            raise ValueError("ComfyUI 必须绑定本机回环地址")
        self.registry = TemplateRegistry(self.config_path.parent / self.config.get("templates", "templates"))
        self.state_root = self.config_path.parent / ".agent-state"
        self.state_root.mkdir(exist_ok=True)
        self.cloud = httpx.Client(base_url=server, headers={"Authorization": "Bearer " + self.config["token"]}, timeout=60, follow_redirects=False, trust_env=False)
        self.comfy = httpx.Client(base_url=comfy, timeout=60, follow_redirects=False, trust_env=False)
        self.desktop_workflows = DesktopWorkflows(self.comfy)
        self.stop = threading.Event()
        self.metadata = {}
        self.metadata_at = 0
        self.metadata_lock = threading.Lock()
        self.catalog_errors = []

    def refresh_metadata(self, force=False):
        with self.metadata_lock:
            if force or time.monotonic() - self.metadata_at > 30 or not self.metadata:
                response = self.comfy.get("/object_info")
                response.raise_for_status()
                self.metadata = response.json()
                saved, errors = self.desktop_workflows.scan(self.metadata, force=force)
                self.catalog_errors = self.registry.refresh(self.metadata, saved, errors)
                self.metadata_at = time.monotonic()
            return self.metadata

    def post(self, path, **kwargs):
        return bounded_json(self.cloud, "POST", path, **kwargs)

    def sync_catalog(self):
        online, devices = False, []
        try:
            stats = self.comfy.get("/system_stats", timeout=5)
            stats.raise_for_status()
            devices = stats.json().get("devices", [])
            online = True
            self.refresh_metadata()
        except httpx.HTTPError:
            pass
        self.post("/v1/worker/catalog", json={"templates": self.registry.catalog(), "comfyOnline": online,
                  "gpu": devices[0].get("name", "") if devices else "", "nodes": node_catalog(self.metadata),
                  "inventory": inventory_from_info(self.metadata), "catalogErrors": self.catalog_errors,
                  "workflowEditing": bool(self.metadata)})

    def heartbeat_loop(self):
        while not self.stop.wait(10):
            try:
                self.sync_catalog()
            except httpx.HTTPError:
                LOG.warning("任务站暂时不可达；本机任务记录已保留")

    def state(self, job_id, state, message):
        job_identifier(job_id)
        self.post(f"/v1/worker/jobs/{job_id}/state", json={"state": state, "message": message[:500]})

    def read_journal(self, job_id):
        path = self.state_root / (job_id + ".json")
        return json.loads(path.read_text(encoding="utf-8")) if path.exists() else {"stage": "new", "uploaded": []}

    def save_journal(self, job_id, journal):
        path = self.state_root / (job_id + ".json")
        temp = path.with_suffix(".tmp")
        temp.write_text(json.dumps(journal), encoding="utf-8")
        os.replace(temp, path)

    def recover_prompt(self, job_id):
        queue = self.comfy.get("/queue").json()
        candidates = queue.get("queue_running", []) + queue.get("queue_pending", [])
        history = self.comfy.get("/history", params={"max_items": 100}).json()
        candidates += [record.get("prompt", []) for record in history.values()]
        for entry in candidates:
            if len(entry) > 3 and entry[3].get("toolcase_job_id") == job_id:
                return entry[1]
        return None

    def release_memory_if_idle(self):
        try:
            response = self.comfy.get('/queue', timeout=5)
            response.raise_for_status()
            queue = response.json()
            if queue['queue_running'] or queue['queue_pending']:
                return
            self.comfy.post('/free', json={'unload_models': True, 'free_memory': True}, timeout=5).raise_for_status()
            # /free queues cleanup on ComfyUI's worker; HTTP 200 is not completion.
            deadline = time.monotonic() + 30
            while time.monotonic() < deadline:
                response = self.comfy.get('/system_stats', timeout=5)
                response.raise_for_status()
                devices = response.json()['devices']
                if devices and all(d['torch_vram_total'] - d['torch_vram_free'] <= 64 * 1024**2 for d in devices):
                    LOG.info('生成结束，已请求释放模型与缓存；PyTorch 显存占用已回落')
                    return
                if self.stop.wait(0.25):
                    return
            LOG.warning('已请求释放模型与缓存，显存尚未回落；请检查 ComfyUI 日志')
        except (httpx.HTTPError, ValueError, KeyError, TypeError):
            # A cleanup failure must not discard a successfully generated file.
            LOG.warning('未能确认模型与缓存释放；保留生成结果，请检查 ComfyUI 日志')

    def process(self, job):
        job_id, payload, fingerprint = validate_task(job)
        journal = self.read_journal(job_id)
        if journal["stage"] != "new" and journal.get("payload_sha256") != fingerprint:
            raise ValueError("任务内容与本机记录不一致；拒绝恢复篡改或旧版未绑定的任务")
        if journal["stage"] == "completed":
            return
        custom = payload.get("workflow")
        # Even built-in templates require fresh, local validation. No offline fallback.
        nodes = node_catalog(self.refresh_metadata(force=True))
        if custom:
            selected = prepare_workflow(custom["graph"], nodes, custom["name"], custom["mode"], payload["template"])
        else:
            source = self.registry.templates.get(payload["template"])
            if source is None:
                raise ValueError("原工作流已不可用，请刷新目录")
            selected = prepare_workflow(source["workflow"], nodes, source["name"], source["mode"], source["id"])
        if payload.get("inputId") and not selected["requiresImage"]:
            raise ValueError("文生工作流不接受额外参考文件")
        # Reject invalid values before downloading or uploading any input.
        compile_workflow(selected, payload["values"], "toolcase-reference" if payload.get("inputId") else None, job_id)
        if job["cancel"] and journal["stage"] == "new":
            self.state(job_id, "cancelled", "任务已取消")
            return
        if journal["stage"] == "new":
            # This quota is enforced locally even if the remote broker is compromised.
            recent = sum(1 for p in self.state_root.glob("*.json") if p.stat().st_mtime > time.time() - 86400)
            if recent >= 100:
                raise ValueError("电脑端每日 100 项任务上限已达到")
            reference = None
            if payload.get("inputId"):
                data = bytearray()
                with self.cloud.stream("GET", "/v1/files/" + payload["inputId"]) as response:
                    response.raise_for_status()
                    for chunk in response.iter_bytes(65536):
                        data.extend(chunk)
                        if len(data) > 20 * 1024 * 1024:
                            raise ValueError("参考图超过电脑端大小限制")
                data = clean_reference(data)
                input_name = "toolcase_" + job_id + ".jpg"
                upload = self.comfy.post("/upload/image", files={"image": (input_name, data, "image/jpeg")}, data={"type": "input", "overwrite": "false"})
                upload.raise_for_status()
                result = upload.json()
                reference = result["name"]
                if (result.get("type", "input") != "input" or result.get("subfolder")
                        or not re.fullmatch(r"toolcase_" + job_id + r"(?: \([0-9]+\))?\.jpg", reference)):
                    raise ValueError("ComfyUI 返回的参考图路径不属于当前任务")
            # Even a compromised broker cannot add executable nodes or arbitrary file paths.
            workflow = compile_workflow(selected, payload["values"], reference, job_id)
            journal.update(stage="submitting", payload_sha256=fingerprint)
            self.save_journal(job_id, journal)
            response = self.comfy.post("/prompt", json={"prompt": workflow, "client_id": "toolcase-agent", "extra_data": {"toolcase_job_id": job_id}})
            if response.status_code == 400:
                self.state(job_id, "failed", "ComfyUI 拒绝了工作流参数；请检查本机模板和模型文件")
                LOG.error("工作流校验失败，节点错误：%s", json.dumps(response.json().get("node_errors", {}), ensure_ascii=False)[:1500])
                return
            response.raise_for_status()
            journal.update(stage="submitted", prompt_id=response.json()["prompt_id"])
            self.save_journal(job_id, journal)
        elif journal["stage"] == "submitting":
            recovered = self.recover_prompt(job_id)
            if not recovered:
                self.state(job_id, "failed", "提交时连接中断，无法确认是否已生成；为避免重复消耗，已停止自动重试")
                return
            journal.update(stage="submitted", prompt_id=recovered)
            self.save_journal(job_id, journal)
        prompt_id = journal["prompt_id"]
        if not isinstance(prompt_id, str) or str(uuid.UUID(prompt_id)) != prompt_id:
            raise ValueError("ComfyUI 任务标识不合法")
        self.state(job_id, "running", "ComfyUI 已接收，正在生成或等待显卡")
        cancelled = False
        missing_prompt_checks = 0
        while not self.stop.is_set():
            history_response = self.comfy.get("/history/" + prompt_id)
            history_response.raise_for_status()
            history = history_response.json().get(prompt_id)
            remote = bounded_json(self.cloud, "GET", "/v1/jobs/" + job_id)
            if type(remote.get("cancel")) is not bool:
                raise ValueError("任务站取消状态不合法")
            cancelled = remote["cancel"]
            if cancelled:
                queue = self.comfy.get("/queue").json()
                if any(entry[1] == prompt_id for entry in queue.get("queue_pending", [])):
                    self.comfy.post("/queue", json={"delete": [prompt_id]}).raise_for_status()
                    self.state(job_id, "cancelled", "已移除等待中的生成任务")
                    return
                if not history:
                    self.state(job_id, "running", "已停止回传；正在运行的计算完成后结束，避免中断其他任务")
            if history:
                break
            queue_response = self.comfy.get('/queue')
            queue_response.raise_for_status()
            queue = queue_response.json()
            present = any(entry[1] == prompt_id for entry in queue['queue_running'] + queue['queue_pending'])
            missing_prompt_checks = 0 if present else missing_prompt_checks + 1
            if missing_prompt_checks >= 3:
                self.state(job_id, 'failed', 'ComfyUI 已丢失此任务，可能曾崩溃或重启；请重新生成，不会自动重复提交')
                return
            self.stop.wait(3)
        if self.stop.is_set():
            return
        self.release_memory_if_idle()
        if cancelled:
            self.state(job_id, "cancelled", "已取消成品回传")
            return
        status = history.get("status", {})
        if status.get("status_str") == "error":
            self.state(job_id, "failed", "ComfyUI 执行失败，请在电脑端查看显存、模型或节点错误")
            return
        outputs = [own_output(item, job_id) for item in self.registry.outputs_for(selected["outputNodes"], history)]
        if not outputs:
            self.state(job_id, "failed", "工作流结束但未发现受支持的图片或视频成品")
            return
        self.state(job_id, "uploading", "生成完成，正在回传成品")
        existing = bounded_json(self.cloud, "GET", "/v1/jobs/" + job_id)["artifacts"]
        existing_names = {a["name"] for a in existing}
        for item in outputs:
            name = item["filename"]
            if name in existing_names:
                continue
            file_path = self.state_root / (job_id + "-" + name)
            try:
                size = 0
                with self.comfy.stream("GET", "/view", params=item) as response:
                    response.raise_for_status()
                    with file_path.open("wb") as output:
                        for chunk in response.iter_bytes():
                            size += len(chunk)
                            if size > 300 * 1024 * 1024:
                                raise ValueError("成品超过 300 MiB 上限")
                            output.write(chunk)
                with file_path.open("rb") as data:
                    self.post(f"/v1/worker/jobs/{job_id}/artifacts", files={"file": (name, data, mimetypes.guess_type(name)[0] or "application/octet-stream")})
            finally:
                file_path.unlink(missing_ok=True)
        self.state(job_id, "completed", "成品已就绪")
        journal["stage"] = "completed"
        self.save_journal(job_id, journal)

    def run(self, once=False):
        self.sync_catalog()
        heartbeat = threading.Thread(target=self.heartbeat_loop, daemon=True)
        heartbeat.start()
        try:
            while not self.stop.is_set():
                try:
                    job = self.post("/v1/worker/claim", json={})["job"]
                    if job:
                        try:
                            job_identifier(job.get("id") if isinstance(job, dict) else None)
                            LOG.info("开始处理任务 %s", job["id"][:8])
                            self.process(job)
                        except (ValueError, KeyError, TypeError, OSError, Image.DecompressionBombError) as exc:
                            LOG.warning("拒绝不符合电脑端生成策略的任务：%s", type(exc).__name__)
                            if isinstance(job, dict) and isinstance(job.get("id"), str) and re.fullmatch(r"[0-9a-f]{32}", job["id"]):
                                self.state(job["id"], "failed", str(exc)[:250])
                    elif once:
                        return
                    if once:
                        return
                except httpx.HTTPError as exc:
                    LOG.warning("连接暂时中断（%s），10 秒后恢复；不重复提交已记录任务", type(exc).__name__)
                    self.stop.wait(10)
                except (ValueError, KeyError, TypeError, AttributeError):
                    LOG.warning("任务站返回了非法响应；未执行，10 秒后重试")
                    self.stop.wait(10)
                self.stop.wait(3)
        finally:
            self.stop.set()
            heartbeat.join(timeout=12)
            self.cloud.close()
            self.comfy.close()


def main():
    parser = argparse.ArgumentParser(description="工具匣电脑端执行器")
    parser.add_argument("--config", required=True)
    parser.add_argument("--once", action="store_true")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    try:
        Agent(args.config).run(args.once)
    except KeyboardInterrupt:
        print("执行器已退出；已提交到 ComfyUI 的任务仍由 ComfyUI 管理。")


if __name__ == "__main__":
    main()
