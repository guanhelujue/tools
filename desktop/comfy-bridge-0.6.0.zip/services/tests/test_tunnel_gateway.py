from fastapi.testclient import TestClient
from toolcase.broker import create_app
from toolcase.local_share import parse_tunnel_url
from toolcase.local_share import tunnel_healthy
import httpx
import pytest
import json


def test_public_listener_only_accepts_mobile_pairing(tmp_path):
    public=create_app(tmp_path,mobile_only=True)
    local=create_app(tmp_path)
    client,private=TestClient(public),TestClient(local)
    store=public.state.store
    code=store.create_pairing('worker')
    assert client.post('/v1/pair',json={'code':code,'name':'invalid'}).status_code==401
    response=private.post('/v1/pair',json={'code':code,'name':'PC'})
    assert response.status_code==200  # The rejected public request did not consume the code.
    assert client.get('/v1/jobs',headers={'Authorization':'Bearer '+response.json()['token']}).status_code==403
    phone=client.post('/v1/pair',json={'code':store.create_pairing('mobile'),'name':'Phone'})
    assert phone.status_code==200
    headers={'Authorization':'Bearer '+phone.json()['token']}
    assert client.get('/v1/jobs',headers=headers).status_code==200
    assert client.get('/v1/jobs').status_code==401
    for path in ['/prompt','/object_info','/view','/queue','/history','/v1/worker/claim','/anything/artifacts']:
        assert client.post(path,headers=headers,json={}).status_code==404
    assert client.get('/v1/files/not-a-file-id',headers=headers).status_code==404


def test_tunnel_address_comes_from_forward_event_not_provider_advertising():
    assert parse_tunnel_url('Manage custom domains: https://admin.localhost.run/') is None
    assert parse_tunnel_url(json.dumps({'type':'log','data':'https://admin.localhost.run'})) is None
    event={'type':'v1.tcpip_forward.register.accepted','id':'localhost/abc123.lhr.life','data':'https://abc123.lhr.life\r\nmanage at https://admin.localhost.run'}
    assert parse_tunnel_url(json.dumps(event))=='https://abc123.lhr.life'
    assert parse_tunnel_url(json.dumps({**event,'id':'localhost/abc.example.org'})) is None


@pytest.mark.parametrize('status,body,expected', [(200,b'{"service":"toolcase"}',True),
    (502,b'no tunnel',False),(200,b'x'*16001,False),(200,b'{"service":"other"}',False)])
def test_health_probe_is_bounded_and_detects_dead_forward(monkeypatch,status,body,expected):
    import toolcase.local_share as module
    original = httpx.Client
    monkeypatch.setattr(module.httpx,'Client',lambda **kwargs: original(transport=httpx.MockTransport(lambda request: httpx.Response(status,content=body)),**kwargs))
    assert tunnel_healthy('https://testing.lhr.life') is expected
