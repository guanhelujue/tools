import io
import json
import time
from concurrent.futures import ThreadPoolExecutor

import pytest
from fastapi.testclient import TestClient
from PIL import Image

from toolcase.broker import create_app, MAX_INPUT
from toolcase.templates import TemplateRegistry
from toolcase.contracts import validate_values
from toolcase.agent import validate_server_url


@pytest.fixture
def setup(tmp_path):
    app = create_app(tmp_path)
    client = TestClient(app)
    store = app.state.store
    devices = {}
    for name, role in [('alice','mobile'),('bob','mobile'),('pc','worker'),('other_pc','worker')]:
        code = store.create_pairing(role)
        result = client.post('/v1/pair', json={'code':code,'name':name})
        assert result.status_code == 200
        devices[name] = result.json()
    headers = {key:{'Authorization':'Bearer '+value['token']} for key,value in devices.items()}
    template = {'id':'test','name':'Test','mode':'t2i','maxPixels':512*512,'requiresImage':False,'fields':[
        {'id':'prompt','label':'提示词','kind':'text','required':True,'default':'cat'},
        {'id':'steps','label':'步数','kind':'int','min':1,'max':40,'step':1,'default':8}]}
    assert client.post('/v1/worker/catalog', headers=headers['pc'], json={'templates':[template]}).status_code == 200
    body={'requestId':'test-request-1','worker':devices['pc']['deviceId'],'template':'test','values':{'prompt':'cat','steps':8}}
    return client,store,headers,body,devices


def png():
    buffer=io.BytesIO();Image.new('RGB',(32,32),'orange').save(buffer,'PNG');return buffer.getvalue()


def test_pair_single_use_expiry_hash_and_revocation(setup):
    c,s,h,b,d=setup
    code=s.create_pairing('mobile')
    with ThreadPoolExecutor(2) as pool:
        results=list(pool.map(lambda _:s.pair(code,'phone'),range(2)))
    assert sum(x is not None for x in results)==1
    assert s.pair(s.create_pairing('mobile',minutes=-1),'expired') is None
    with s.db() as db:
        row=db.execute('SELECT token_hash FROM devices WHERE id=?',(d['alice']['deviceId'],)).fetchone()
        assert row[0]!=d['alice']['token'] and len(row[0])==64
    s.revoke(d['alice']['deviceId'])
    assert c.get('/v1/jobs',headers=h['alice']).status_code==401


def test_auth_before_upload_parsing_and_roles(setup):
    c,s,h,b,d=setup
    assert c.post('/v1/uploads',content=b'not multipart').status_code==401
    assert c.post('/v1/uploads',headers=h['pc'],files={'file':('x.png',png())}).status_code==403
    assert c.post('/v1/worker/claim',headers=h['alice'],json={}).status_code==403
    assert c.post('/v1/jobs',headers=h['alice'],json={**b,'workflow':{}}).status_code==422
    assert c.post('/v1/jobs',headers=h['alice'],json={**b,'values':{'script':'x'}}).status_code==400


def test_idempotency_isolation_atomic_claim_and_cancel(setup):
    c,s,h,b,d=setup
    first=c.post('/v1/jobs',headers=h['alice'],json=b).json()
    assert c.post('/v1/jobs',headers=h['alice'],json=b).json()['id']==first['id']
    assert c.post('/v1/jobs',headers=h['alice'],json={**b,'values':{'prompt':'different'}}).status_code==409
    assert c.get('/v1/jobs/'+first['id'],headers=h['bob']).status_code==404
    assert c.get('/v1/jobs',headers=h['bob']).json()=={'jobs':[]}
    assert c.post('/v1/worker/claim',headers=h['other_pc'],json={}).json()['job'] is None
    claimed=c.post('/v1/worker/claim',headers=h['pc'],json={}).json()['job']
    assert claimed['id']==first['id']
    assert c.post('/v1/worker/claim',headers=h['pc'],json={}).json()['job']['id']==first['id']
    assert c.post('/v1/worker/jobs/'+first['id']+'/state',headers=h['pc'],json={'state':'completed'}).status_code==400
    assert c.post('/v1/jobs/'+first['id']+'/cancel',headers=h['bob'],json={}).status_code==404
    cancelled=c.post('/v1/jobs/'+first['id']+'/cancel',headers=h['alice'],json={}).json()
    assert cancelled['cancel'] and cancelled['state']=='running'


def test_reference_and_artifact_access_thumbnail(setup):
    c,s,h,b,d=setup
    assert c.post('/v1/uploads',headers=h['alice'],files={'file':('x.png',b'not an image')}).status_code==400
    uploaded=c.post('/v1/uploads',headers=h['alice'],files={'file':('x.png',png())}).json()
    path='/v1/files/'+uploaded['id']
    assert c.get(path,headers=h['bob']).status_code==404
    assert c.get(path,headers=h['pc']).status_code==404
    assert c.post('/v1/jobs',headers=h['bob'],json={**b,'inputId':uploaded['id']}).status_code==400
    job=c.post('/v1/jobs',headers=h['alice'],json={**b,'inputId':uploaded['id']}).json()
    c.post('/v1/worker/claim',headers=h['pc'],json={})
    assert c.get(path,headers=h['pc']).status_code==200
    artifact_path='/v1/worker/jobs/'+job['id']+'/artifacts'
    assert c.post(artifact_path,headers=h['other_pc'],files={'file':('x.png',png())}).status_code==404
    result=c.post(artifact_path,headers=h['pc'],files={'file':('x.png',png())})
    assert result.status_code==201
    output_path='/v1/files/'+result.json()['id']
    assert c.get(output_path,headers=h['bob']).status_code==404
    assert c.get(output_path,headers=h['pc']).status_code==404
    assert c.get(output_path,headers=h['alice']).content==png()
    assert c.get(output_path+'/thumbnail',headers=h['alice']).status_code==200
    assert c.get(output_path+'/thumbnail',headers=h['bob']).status_code==404
    assert c.post('/v1/worker/jobs/'+job['id']+'/state',headers=h['pc'],json={'state':'completed'}).status_code==200
    assert c.get(path,headers=h['pc']).status_code==404
    assert c.post(artifact_path,headers=h['pc'],files={'file':('x.png',png())}).status_code==409


def test_resource_and_queued_cancel_limits(setup):
    c,s,h,b,d=setup
    assert c.post('/v1/jobs',headers=h['alice'],json={**b,'values':{'steps':41}}).status_code==400
    assert c.post('/v1/jobs',headers=h['alice'],json={**b,'values':{'steps':True}}).status_code==400
    for i in range(5):
        r=c.post('/v1/jobs',headers=h['alice'],json={**b,'requestId':f'request-num-{i}'})
        assert r.status_code==201
    assert c.post('/v1/jobs',headers=h['alice'],json=b).status_code==429
    last=r.json()['id']
    assert c.post('/v1/jobs/'+last+'/cancel',headers=h['alice'],json={}).json()['state']=='cancelled'
    assert c.post('/v1/jobs',headers=h['alice'],json=b).status_code==201
    assert c.post('/v1/uploads',headers={**h['alice'],'Content-Length':str(MAX_INPUT+100000)},content=b'x').status_code==413


def test_template_compilation_is_local_and_paths_are_checked():
    from pathlib import Path
    registry=TemplateRegistry(Path(__file__).parents[1]/'templates')
    original=json.dumps(registry.templates,sort_keys=True)
    for template in registry.templates.values():
        defaults={f['id']:f['default'] for f in template['fields']}
        validate_values(template,defaults)
        compiled=registry.compile(template['id'],defaults,'reference.jpg','job123')
        assert compiled
        with pytest.raises(ValueError):registry.compile(template['id'],{**defaults,'python':'bad'})
        node=template['outputNodes'][0]
        with pytest.raises(ValueError):
            registry.outputs(template['id'],{'outputs':{node:{'images':[{'filename':'a.png','subfolder':'../../secret','type':'output'}]}}})
        assert registry.outputs(template['id'],{'outputs':{node:{'images':[{'filename':'a.mp4','subfolder':'Toolcase','type':'output'}]}}})[0]['filename']=='a.mp4'
    assert original==json.dumps(registry.templates,sort_keys=True)
    assert all('workflow' not in t and all('binds' not in f for f in t['fields']) for t in registry.catalog())


@pytest.mark.parametrize('url',['http://example.org','https://user:pass@example.org','https://example.org/path','file:///etc/passwd','http://192.168.0.1'])
def test_non_private_or_insecure_agent_config_rejected(url):
    with pytest.raises(ValueError):validate_server_url(url,allow_local=True)


def test_untrusted_broker_cannot_write_worker_paths(tmp_path):
    from toolcase.agent import Agent
    agent=Agent.__new__(Agent)
    agent.state_root=tmp_path
    with pytest.raises(ValueError,match='任务编号'):
        agent.process({'id':'../../outside','payload':{}})
    with pytest.raises(ValueError,match='参考图编号'):
        agent.process({'id':'a'*32,'payload':{'inputId':'../../outside'}})
    assert not list(tmp_path.iterdir())


def test_revoked_mobile_cancels_queued_jobs(setup):
    c,s,h,b,d=setup
    job=c.post('/v1/jobs',headers=h['alice'],json=b).json()
    s.revoke(d['alice']['deviceId'])
    assert c.post('/v1/worker/claim',headers=h['pc'],json={}).json()['job'] is None
    with s.db() as db:
        assert db.execute('SELECT state FROM jobs WHERE id=?',(job['id'],)).fetchone()[0]=='cancelled'
