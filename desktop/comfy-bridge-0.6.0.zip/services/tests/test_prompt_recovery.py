import json

import httpx

from test_compromised_relay import executor, task, PROMPT
from test_editable_workflows import info, graph
from toolcase.safety import validate_task


def test_prompt_lost_after_comfy_restart_fails_without_resubmission(executor, graph, monkeypatch):
    job = task(graph)
    _, _, fingerprint = validate_task(job)
    executor.agent.save_journal(job['id'], {'stage': 'submitted', 'prompt_id': PROMPT, 'payload_sha256': fingerprint})
    original = executor.agent.comfy._transport.handler
    requests, state_updates = [], []
    def comfy(request):
        requests.append(request.url.path)
        if request.url.path == '/history/' + PROMPT:
            return httpx.Response(200, json={})
        return original(request)
    def relay(request):
        if request.method == 'GET': return httpx.Response(200, json={'cancel': False})
        state_updates.append(json.loads(request.content))
        return httpx.Response(200, json={'ok': True})
    executor.agent.comfy.close()
    executor.agent.cloud.close()
    executor.agent.comfy = httpx.Client(base_url='http://127.0.0.1:8188', transport=httpx.MockTransport(comfy))
    executor.agent.cloud = httpx.Client(base_url='https://relay.invalid', transport=httpx.MockTransport(relay))
    waits = []
    def wait(seconds):
        waits.append(seconds)
        if len(waits) == 4:
            executor.agent.stop.set()
        return executor.agent.stop.is_set()
    monkeypatch.setattr(executor.agent.stop, 'wait', wait)
    executor.agent.process(job)
    assert state_updates[-1]['state'] == 'failed', 'Lost ComfyUI prompt remained running indefinitely'
    assert '/prompt' not in requests
    assert requests.count('/queue') >= 3
