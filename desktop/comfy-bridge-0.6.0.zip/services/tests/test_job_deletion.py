import sqlite3

import pytest
from starlette.datastructures import UploadFile
from fastapi.testclient import TestClient

from test_security import setup, png
from toolcase.broker import create_app
from toolcase.store import Store


def test_delete_is_owned_idempotent_and_cannot_replay_submission(setup):
    client, store, headers, body, devices = setup
    job = client.post('/v1/jobs', headers=headers['alice'], json=body).json()
    path = '/v1/jobs/' + job['id']
    public = TestClient(create_app(store.root, mobile_only=True))
    assert public.delete(path).status_code == 401
    assert public.delete(path, headers=headers['pc']).status_code == 403
    assert public.delete(path, headers=headers['bob']).status_code == 404
    assert public.delete(path, headers=headers['alice']).status_code == 200
    assert public.delete(path, headers=headers['alice']).status_code == 200
    assert public.get('/v1/jobs', headers=headers['alice']).json() == {'jobs': []}
    assert public.get(path, headers=headers['alice']).status_code == 404
    assert public.post(path + '/cancel', headers=headers['alice'], json={}).status_code == 404
    assert client.post('/v1/worker/claim', headers=headers['pc'], json={}).json()['job'] is None
    assert client.post('/v1/jobs', headers=headers['alice'], json=body).status_code == 410
    with store.db() as db:
        removed = db.execute('SELECT payload,template FROM jobs WHERE id=?', (job['id'],)).fetchone()
        assert removed['payload'] == '{}' and removed['template'] == ''


@pytest.mark.parametrize('state', ['running', 'uploading', 'completed', 'failed', 'cancelled'])
def test_delete_removes_results_but_preserves_shared_reference_and_other_jobs(setup, state):
    client, store, headers, body, devices = setup
    reference = client.post('/v1/uploads', headers=headers['alice'], files={'file': ('ref.png', png())}).json()['id']
    job = client.post('/v1/jobs', headers=headers['alice'], json={**body, 'inputId': reference}).json()
    client.post('/v1/worker/claim', headers=headers['pc'], json={})
    artifact_path = '/v1/worker/jobs/' + job['id'] + '/artifacts'
    artifact = client.post(artifact_path, headers=headers['pc'], files={'file': ('result.png', png())}).json()['id']
    assert client.post('/v1/worker/jobs/' + job['id'] + '/state', headers=headers['pc'], json={'state': state}).status_code == 200
    other = client.post('/v1/jobs', headers=headers['alice'], json={**body, 'requestId': 'another-request', 'inputId': reference}).json()
    assert client.delete('/v1/jobs/' + job['id'], headers=headers['alice']).status_code == 200
    assert not (store.root / 'files' / artifact).exists()
    assert (store.root / 'files' / reference).exists()
    for suffix in ['', '/thumbnail']:
        assert client.get('/v1/files/' + artifact + suffix, headers=headers['alice']).status_code == 404
    assert client.get('/v1/jobs/' + job['id'], headers=headers['pc']).json()['cancel']
    assert client.post(artifact_path, headers=headers['pc'], files={'file': ('late.png', png())}).status_code == 409
    assert client.post('/v1/worker/jobs/' + job['id'] + '/state', headers=headers['pc'], json={'state': 'running'}).status_code == 409
    assert client.post('/v1/worker/claim', headers=headers['pc'], json={}).json()['job']['id'] == other['id']


def test_deleting_during_artifact_upload_cannot_recreate_result(setup, monkeypatch):
    client, store, headers, body, devices = setup
    job = client.post('/v1/jobs', headers=headers['alice'], json=body).json()
    client.post('/v1/worker/claim', headers=headers['pc'], json={})
    original = UploadFile.read
    deleted = False
    async def racing_read(file, size=-1):
        nonlocal deleted
        chunk = await original(file, size)
        if chunk and not deleted:
            deleted = True
            assert client.delete('/v1/jobs/' + job['id'], headers=headers['alice']).status_code == 200
        return chunk
    monkeypatch.setattr(UploadFile, 'read', racing_read)
    response = client.post('/v1/worker/jobs/' + job['id'] + '/artifacts', headers=headers['pc'], files={'file': ('result.png', png())})
    assert response.status_code == 409
    assert not list((store.root / 'files').iterdir())


def test_existing_database_migrates_without_losing_job_history(setup):
    client, store, headers, body, devices = setup
    job = client.post('/v1/jobs', headers=headers['alice'], json=body).json()
    with sqlite3.connect(store.path) as db:
        if 'deleted' in [row[1] for row in db.execute('PRAGMA table_info(jobs)')]:
            db.execute('ALTER TABLE jobs DROP COLUMN deleted')
    Store(store.root)
    assert client.get('/v1/jobs/' + job['id'], headers=headers['alice']).status_code == 200
    assert client.delete('/v1/jobs/' + job['id'], headers=headers['alice']).status_code == 200
