import copy
import json

import httpx
import pytest

from test_editable_workflows import info, graph
from toolcase.desktop_workflows import DesktopWorkflows, saved_graph_to_api
from toolcase.templates import TemplateRegistry


def test_reads_saved_workflow_without_replacing_prompt_or_changing_source(info, graph, tmp_path):
    original = copy.deepcopy(graph)
    paths = []
    def handler(request):
        paths.append((request.method, request.url.path))
        if request.url.path == '/userdata':
            return httpx.Response(200, json=[{'path': 'folder/my workflow.json', 'size': 100, 'modified': 1}])
        return httpx.Response(200, json=graph)
    with httpx.Client(base_url='http://127.0.0.1:8188', transport=httpx.MockTransport(handler)) as client:
        scanner = DesktopWorkflows(client)
        sources, errors = scanner.scan(info, force=True)
        assert errors == []
        assert sources[0]['sourceFile'] == 'folder/my workflow.json'
        assert sources[0]['workflow']['2']['inputs']['text'] == 'mountain'
        assert sources[0]['workflow']['4']['inputs']['width'] == 512
        assert sources[0]['workflow']['1']['inputs']['ckpt_name'] == 'a.safetensors'
        registry = TemplateRegistry(tmp_path)
        registry.refresh(info, sources, errors)
        assert registry.catalog()[0]['source'] == 'computer'
        scanner.scan(info, force=True)
        assert sum(path.startswith('/userdata/') for _, path in paths) == 1
        assert all(method == 'GET' for method, _ in paths)
        assert graph == original


def test_modified_and_deleted_files_refresh_without_stale_entries(info, graph):
    stamp = [1]
    def handler(request):
        if request.url.path == '/userdata':
            return httpx.Response(200, json=[] if stamp[0] == 3 else [{'path':'a.json','size':100,'modified':stamp[0]}])
        source = copy.deepcopy(graph)
        source['2']['inputs']['text'] = str(stamp[0])
        return httpx.Response(200, json=source)
    with httpx.Client(base_url='http://localhost', transport=httpx.MockTransport(handler)) as client:
        scanner=DesktopWorkflows(client)
        first=scanner.scan(info,force=True)[0][0]
        stamp[0]=2
        second=scanner.scan(info,force=True)[0][0]
        assert first['id']==second['id']
        assert second['workflow']['2']['inputs']['text']=='2'
        stamp[0]=3
        assert scanner.scan(info,force=True)==([],[])


def test_unsupported_file_is_reported_and_other_files_remain_available(info, graph):
    def handler(request):
        if request.url.path == '/userdata':
            return httpx.Response(200,json=[{'path':'good.json','size':100,'modified':1},{'path':'bad.json','size':100,'modified':1},{'path':'../secret.json','size':1}])
        if 'bad.json' in request.url.path:
            return httpx.Response(200,json={'nodes':[{'id':1,'type':'UnreviewedNode'}],'links':[]})
        assert 'secret' not in request.url.path
        return httpx.Response(200,json=graph)
    with httpx.Client(base_url='http://localhost',transport=httpx.MockTransport(handler)) as client:
        sources,errors=DesktopWorkflows(client).scan(info,force=True)
        assert len(sources)==1 and len(errors)==1
        assert errors[0]['name']=='bad' and 'UnreviewedNode' in errors[0]['reason']


def test_canvas_respects_explicit_widget_order_and_rejects_ambiguous_widgets(info):
    metadata=copy.deepcopy(info)
    metadata['EmptyLatentImage']['input_order']={'required':['height','width','batch_size']}
    source={'nodes':[{'id':1,'type':'EmptyLatentImage','widgets_values':[768,512,1]}],'links':[]}
    assert saved_graph_to_api(source,metadata)['1']['inputs']=={'height':768,'width':512,'batch_size':1}
    source['nodes'][0]['widgets_values'].append('unknown')
    with pytest.raises(ValueError,match='控件'):
        saved_graph_to_api(source,metadata)


def test_failed_scan_does_not_relabel_stale_files_as_fresh(info, graph):
    failing=[False]
    def handler(request):
        if failing[0]: return httpx.Response(503)
        return httpx.Response(200,json=[{'path':'a.json','size':100,'modified':1}] if request.url.path=='/userdata' else graph)
    with httpx.Client(base_url='http://localhost',transport=httpx.MockTransport(handler)) as client:
        scanner=DesktopWorkflows(client)
        assert scanner.scan(info,force=True)[0]
        failing[0]=True
        sources,errors=scanner.scan(info,force=True)
        assert not sources and errors
