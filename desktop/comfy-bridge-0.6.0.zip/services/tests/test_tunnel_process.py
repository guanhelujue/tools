import json
import os
import sys
import time
import socket
import subprocess
import pytest

from toolcase.local_share import connect_tunnel, end_process


def test_connect_uses_forward_event_and_cleans_owned_process():
    event = {'type':'v1.tcpip_forward.register.accepted', 'id':'localhost/testing.lhr.life',
             'data':'https://testing.lhr.life'}
    code = "import time; print('https://admin.localhost.run', flush=True); print(%r, flush=True); time.sleep(30)" % json.dumps(event)
    process, url = connect_tunnel([sys.executable, '-u', '-c', code], os.environ.copy(), 0, lambda: False, timeout=3)
    assert url == 'https://testing.lhr.life'
    assert process.poll() is None
    end_process(process)
    assert process.poll() is not None


def test_stop_during_connect_terminates_child(monkeypatch):
    import toolcase.local_share as module
    original = module.subprocess.Popen
    children = []
    def record(*args, **kwargs):
        child = original(*args, **kwargs)
        if args[0][0] == sys.executable:
            children.append(child)
        return child
    monkeypatch.setattr(module.subprocess, 'Popen', record)
    deadline = time.monotonic() + 0.2
    result = connect_tunnel([sys.executable, '-u', '-c', 'import time; time.sleep(30)'], os.environ.copy(), 0,
                            lambda: time.monotonic() >= deadline, timeout=5)
    assert result == (None, None)
    assert len(children) == 1 and children[0].poll() is not None


def test_failed_connection_returns_for_supervisor_retry():
    result = connect_tunnel([sys.executable, '-u', '-c', 'raise SystemExit(1)'], os.environ.copy(), 0, lambda: False, timeout=2)
    assert result == (None, None)


@pytest.mark.skipif(os.name != 'nt', reason='Windows venv launchers create child processes')
def test_stop_owned_windows_python_tree_closes_listener(tmp_path):
    port_file = tmp_path / 'port.txt'
    code = "import socket,time,pathlib; s=socket.socket(); s.bind(('127.0.0.1',0)); s.listen(); pathlib.Path(%r).write_text(str(s.getsockname()[1])); time.sleep(30)" % str(port_file)
    process = subprocess.Popen([sys.executable, '-c', code], creationflags=subprocess.CREATE_NO_WINDOW)
    try:
        deadline = time.monotonic() + 5
        while not port_file.exists() and time.monotonic() < deadline:
            time.sleep(.05)
        port = int(port_file.read_text())
        with socket.create_connection(('127.0.0.1', port), timeout=1): pass
        end_process(process)
        with socket.socket() as probe:
            probe.settimeout(1)
            assert probe.connect_ex(('127.0.0.1', port)) != 0
    finally:
        end_process(process)
