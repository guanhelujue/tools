import json

import httpx
import pytest

from test_compromised_relay import executor, task, PROMPT
from test_editable_workflows import info, graph


@pytest.fixture
def memory_executor(executor):
    original = executor.agent.comfy._transport.handler
    state = {'busy': False, 'error': False, 'free_fails': False, 'freed': False, 'stats_reads': 0, 'calls': []}
    def transport(request):
        state['calls'].append((request.method, request.url.path))
        if request.url.path == '/queue':
            return httpx.Response(200, json={'queue_running': [[0, 'another-prompt']] if state['busy'] else [], 'queue_pending': []})
        if request.url.path == '/free':
            assert json.loads(request.content) == {'unload_models': True, 'free_memory': True}
            if state['free_fails']:
                return httpx.Response(503)
            state['freed'] = True
            return httpx.Response(200, json={})
        if request.url.path == '/system_stats':
            state['stats_reads'] += 1
            used = 0 if state['freed'] and state['stats_reads'] > 1 else 6 * 1024**3
            return httpx.Response(200, json={'devices': [{'torch_vram_total': used, 'torch_vram_free': 0}]})
        if request.url.path == '/history/' + PROMPT and state['error']:
            return httpx.Response(200, json={PROMPT: {'status': {'status_str': 'error'}, 'outputs': {}}})
        return original(request)
    executor.agent.comfy.close()
    executor.agent.comfy = httpx.Client(base_url='http://127.0.0.1:8188', transport=httpx.MockTransport(transport))
    return executor, state


@pytest.mark.parametrize('error', [False, True])
def test_terminal_generation_releases_models_before_next_task(memory_executor, graph, error):
    executor, state = memory_executor
    state['error'] = error
    executor.agent.process(task(graph))
    assert state['freed'], 'Completed/failed generation retained model memory'
    assert state['calls'].index(('GET', '/history/' + PROMPT)) < state['calls'].index(('POST', '/free'))
    assert ('GET', '/system_stats') in state['calls']
    assert state['stats_reads'] == 2  # HTTP 200 from /free alone does not mean released.


def test_other_running_prompt_is_not_interrupted_or_unloaded(memory_executor, graph):
    executor, state = memory_executor
    state['busy'] = True
    executor.agent.process(task(graph))
    assert ('GET', '/queue') in state['calls']
    assert ('POST', '/free') not in state['calls']
    assert ('POST', '/interrupt') not in state['calls']


def test_failed_cleanup_keeps_generated_output(memory_executor, graph, caplog):
    executor, state = memory_executor
    state['free_fails'] = True
    executor.agent.process(task(graph))
    assert ('POST', '/free') in state['calls']
    assert executor.agent.read_journal(task(graph)['id'])['stage'] == 'completed'
    assert '释放' in caplog.text
