from concurrent.futures import ThreadPoolExecutor
import time

from fastapi.testclient import TestClient

from toolcase.broker import create_app
from toolcase.store import Store

PASSWORD = 'test-only-secret-4896'


def configured(tmp_path):
    app = create_app(tmp_path, mobile_only=True)
    app.state.store.set_access_password(PASSWORD)
    return TestClient(app), app.state.store


def login(client, password=PASSWORD, **kwargs):
    return client.post('/v1/login', json={'password': password}, **kwargs)


def auth(response):
    assert response.status_code == 200
    return {'Authorization': 'Bearer ' + response.json()['token']}


def test_password_required_role_limits_and_no_secret_echo(tmp_path):
    c, s = configured(tmp_path)
    assert login(c, 'wrong-password').status_code == 401
    assert c.get('/v1/catalog').status_code == 401
    assert c.get('/v1/jobs', headers={'Authorization': 'Bearer ' + PASSWORD}).status_code == 401
    session = login(c)
    h = auth(session)
    assert session.json()['role'] == 'mobile'
    assert c.get('/v1/catalog', headers=h).status_code == 200
    assert c.post('/v1/worker/claim', headers=h, json={}).status_code == 404
    assert c.post('/prompt', headers=h, json={}).status_code == 404
    for path in ('/v1/login', '/v1/pair'):
        bad = c.post(path, json={'password': PASSWORD, 'unexpected': PASSWORD})
        assert bad.status_code == 422 and PASSWORD not in bad.text
    assert c.post('/v1/pair', json={'code': s.create_pairing('mobile'), 'name': 'bypass'}).status_code == 401
    with s.db() as db:
        row = db.execute('SELECT * FROM mobile_access').fetchone()
        assert row['password_hash'] != PASSWORD and len(row['salt']) == 32
        stored = db.execute('SELECT token_hash FROM mobile_sessions').fetchone()[0]
        assert stored != session.json()['token']
    assert PASSWORD.encode() not in s.path.read_bytes()


def test_limit_persists_across_listeners_restart_and_spoofed_ips(tmp_path, monkeypatch):
    c, s = configured(tmp_path)
    # Each listener has a separate Store instance, as the two production processes do.
    private = TestClient(create_app(tmp_path))
    for i in range(5):
        client = c if i % 2 else private
        assert login(client, 'wrong-password', headers={'X-Forwarded-For': f'10.0.0.{i}'}).status_code == 401
    restarted = TestClient(create_app(tmp_path, mobile_only=True))
    blocked = login(restarted)
    assert blocked.status_code == 429
    assert 1 <= int(blocked.headers['Retry-After']) <= 900
    # A blocked request must not run the expensive KDF.
    monkeypatch.setattr(Store, 'password_hash', staticmethod(lambda *args: (_ for _ in ()).throw(AssertionError('KDF called while locked'))))
    assert login(restarted).status_code == 429
    monkeypatch.undo()
    with s.db() as db:
        db.execute('UPDATE login_limit SET window_start=?', (time.time()-901,))
    assert login(restarted).status_code == 200


def test_parallel_guesses_cannot_exceed_budget(tmp_path):
    _, s = configured(tmp_path)
    with ThreadPoolExecutor(8) as pool:
        results = list(pool.map(lambda _: Store(tmp_path).login('wrong-password'), range(8)))
    assert sum(retry == 0 for _, retry in results) == 5
    assert sum(retry > 0 for _, retry in results) == 3


def test_relogin_keeps_history_logout_only_removes_one_session(tmp_path):
    c, s = configured(tmp_path)
    first, second = login(c), login(c)
    h1, h2 = auth(first), auth(second)
    principal = first.json()['deviceId']
    assert second.json()['deviceId'] == principal
    assert first.json()['token'] != second.json()['token']
    # An owned artifact remains owned after login/restart, unlike one-time device pairing.
    file_id = 'a' * 32
    (s.root/'files'/file_id).write_bytes(b'owned image')
    with s.db() as db:
        db.execute('INSERT INTO files VALUES(?,NULL,?,?,?,?,?)', (file_id, principal, 'test.png', 'image/png', 11, time.time()))
    assert c.get('/v1/files/'+file_id, headers=h2).content == b'owned image'
    assert c.post('/v1/logout', headers=h1, json={}).status_code == 200
    assert c.get('/v1/jobs', headers=h1).status_code == 401
    assert c.get('/v1/jobs', headers=h2).status_code == 200
    s.revoke(principal)  # launcher shutdown
    assert c.get('/v1/jobs', headers=h2).status_code == 401
    fresh = login(TestClient(create_app(tmp_path, mobile_only=True)))
    assert fresh.json()['deviceId'] == principal
    assert c.get('/v1/files/'+file_id, headers=auth(fresh)).status_code == 200
    assert c.get('/v1/jobs', headers=h2).status_code == 401  # never resurrect old sessions


def test_rotation_revokes_old_tokens_and_pair_codes_but_not_worker(tmp_path):
    s = Store(tmp_path)
    mobile = s.pair(s.create_pairing('mobile'), 'old phone')
    worker = s.pair(s.create_pairing('worker'), 'worker')
    old_code = s.create_pairing('mobile')
    s.set_access_password(PASSWORD)
    c = TestClient(create_app(tmp_path, mobile_only=True))
    old = login(c)
    s.set_access_password('replacement-test-secret')
    assert s.authenticate(mobile['token']) is None
    assert s.authenticate(worker['token'])['role'] == 'worker'
    assert s.pair(old_code, 'old code') is None
    assert c.get('/v1/jobs', headers=auth(old)).status_code == 401
    assert login(c).status_code == 401
    new = login(c, 'replacement-test-secret')
    assert new.json()['deviceId'] == old.json()['deviceId']
    with s.db() as db:
        db.execute('UPDATE mobile_sessions SET expires=?', (time.time()-1,))
    assert c.get('/v1/jobs', headers=auth(new)).status_code == 401


def test_unconfigured_login_does_not_enable_access(tmp_path):
    c = TestClient(create_app(tmp_path, mobile_only=True))
    assert login(c).status_code == 401
