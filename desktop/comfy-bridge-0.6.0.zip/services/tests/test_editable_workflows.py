import copy
import json

import pytest
from fastapi.testclient import TestClient

from toolcase.broker import create_app
from toolcase.workflows import NODE_MODULES, node_catalog, inventory_from_info, prepare_workflow, compile_workflow


@pytest.fixture
def info():
    metadata = {
        'CheckpointLoaderSimple': {'input': {'required': {'ckpt_name': [['a.safetensors', 'b.safetensors']]}}, 'output': ['MODEL', 'CLIP', 'VAE']},
        'CLIPTextEncode': {'input': {'required': {'clip': ['CLIP'], 'text': ['STRING', {'multiline': True}]}}, 'output': ['CONDITIONING']},
        'EmptyLatentImage': {'input': {'required': {'width': ['INT', {'min': 16, 'max': 16384, 'step': 8}], 'height': ['INT', {'min': 16, 'max': 16384, 'step': 8}], 'batch_size': ['INT', {'min': 1, 'max': 4096}]}}, 'output': ['LATENT']},
        'KSampler': {'input': {'required': {'model': ['MODEL'], 'positive': ['CONDITIONING'], 'negative': ['CONDITIONING'], 'latent_image': ['LATENT'], 'seed': ['INT', {'min': 0, 'max': 2**64-1}], 'steps': ['INT', {'min': 1, 'max': 10000}], 'cfg': ['FLOAT', {'min': 0, 'max': 100, 'step': .1}], 'sampler_name': [['euler']], 'scheduler': [['simple']], 'denoise': ['FLOAT', {'min': 0, 'max': 1, 'step': .01}]}}, 'output': ['LATENT']},
        'VAEDecode': {'input': {'required': {'samples': ['LATENT'], 'vae': ['VAE']}}, 'output': ['IMAGE']},
        'SaveImage': {'input': {'required': {'images': ['IMAGE'], 'filename_prefix': ['STRING']}}, 'output': []},
        'LoadImage': {'input': {'required': {'image': [['private-input.png']]}}, 'output': ['IMAGE', 'MASK']},
        'VAEEncode': {'input': {'required': {'pixels': ['IMAGE'], 'vae': ['VAE']}}, 'output': ['LATENT']},
        'LoraLoaderModelOnly': {'input': {'required': {'model': ['MODEL'], 'lora_name': [['style-a.safetensors', 'style-b.safetensors']], 'strength_model': ['FLOAT', {'min': -20, 'max': 20, 'step': .01}]}}, 'output': ['MODEL']},
    }
    for name, node in metadata.items(): node["python_module"] = NODE_MODULES[name]
    return metadata


@pytest.fixture
def graph():
    def n(t, **inputs): return {'class_type': t, 'inputs': inputs}
    return {'1': n('CheckpointLoaderSimple', ckpt_name='a.safetensors'),
            '2': n('CLIPTextEncode', clip=['1', 1], text='mountain'),
            '3': n('CLIPTextEncode', clip=['1', 1], text='blur'),
            '4': n('EmptyLatentImage', width=512, height=512, batch_size=1),
            '5': n('KSampler', model=['1', 0], positive=['2', 0], negative=['3', 0], latent_image=['4', 0], seed=-1, steps=4, cfg=1.0, sampler_name='euler', scheduler='simple', denoise=1.0),
            '6': n('VAEDecode', samples=['5', 0], vae=['1', 2]),
            '7': n('SaveImage', images=['6', 0], filename_prefix='../../outside')}


def test_real_choices_full_parameter_mapping_and_output_sandbox(info, graph):
    template = prepare_workflow(graph, node_catalog(info))
    fields = {f['id']: f for f in template['fields']}
    assert {v['id'] for v in fields['ckpt_name']['options']} == {'a.safetensors', 'b.safetensors'}
    compiled = compile_workflow(template, {'ckpt_name': 'b.safetensors', 'prompt': 'a lake', 'steps': 2}, None, 'abc')
    assert compiled['1']['inputs']['ckpt_name'] == 'b.safetensors'
    assert compiled['2']['inputs']['text'] == 'a lake'
    assert compiled['5']['inputs']['steps'] == 2
    assert compiled['5']['inputs']['seed'] >= 0
    assert compiled['7']['inputs']['filename_prefix'] == 'Toolcase/abc'
    assert graph['7']['inputs']['filename_prefix'] == '../../outside'
    assert inventory_from_info(info)['loras'][1]['name'] == 'style-b.safetensors'


@pytest.mark.parametrize('change', ['script', 'missing', 'type', 'cycle', 'model', 'steps', 'pixels', 'linked_limit'])
def test_invalid_graphs_fail_closed(info, graph, change):
    if change == 'script': graph['1']['class_type'] = 'PythonExecute'
    if change == 'missing': del graph['1']
    if change == 'type': graph['5']['inputs']['model'] = ['1', 2]
    if change == 'cycle':
        graph['8'] = {'class_type': 'LoraLoaderModelOnly', 'inputs': {'model': ['8', 0], 'lora_name': 'style-a.safetensors', 'strength_model': 1.0}}
    if change == 'model': graph['1']['inputs']['ckpt_name'] = 'C:/private/secret.safetensors'
    if change == 'steps': graph['5']['inputs']['steps'] = 10000
    if change == 'pixels': graph['4']['inputs']['width'] = 16384
    if change == 'linked_limit': graph['4']['inputs']['width'] = ['1', 0]
    with pytest.raises(ValueError): prepare_workflow(graph, node_catalog(info))


def test_references_cannot_read_computer_files(info, graph):
    graph['4'] = {'class_type': 'LoadImage', 'inputs': {'image': 'private-input.png'}}
    graph['8'] = {'class_type': 'VAEEncode', 'inputs': {'pixels': ['4', 0], 'vae': ['1', 2]}}
    graph['5']['inputs']['latent_image'] = ['8', 0]
    nodes = node_catalog(info)
    assert 'private-input.png' not in json.dumps(nodes)
    template = prepare_workflow(graph, nodes, mode='i2i')
    with pytest.raises(ValueError, match='参考图'): compile_workflow(template, {}, None, 'job')
    assert compile_workflow(template, {}, 'uploaded-reference.jpg', 'job')['4']['inputs']['image'] == 'uploaded-reference.jpg'


def test_mobile_prepare_submit_ownership_and_snapshot(tmp_path, info, graph):
    app = create_app(tmp_path)
    c = TestClient(app)
    store = app.state.store
    identities = {role: store.pair(store.create_pairing(role), role) for role in ('worker', 'mobile')}
    headers = {role: {'Authorization': 'Bearer '+v['token']} for role, v in identities.items()}
    wid = identities['worker']['deviceId']
    assert c.post('/v1/worker/catalog', headers=headers['worker'], json={'templates': [], 'nodes': node_catalog(info), 'inventory': inventory_from_info(info), 'workflowEditing': True}).status_code == 200
    body = {'worker': wid, 'name': 'My workflow', 'mode': 't2i', 'graph': graph}
    assert c.post('/v1/workflows/prepare', json=body).status_code == 401
    assert c.post('/v1/workflows/prepare', headers=headers['worker'], json=body).status_code == 403
    prepared = c.post('/v1/workflows/prepare', headers=headers['mobile'], json=body)
    assert prepared.status_code == 200, prepared.text
    workflow = {k: body[k] for k in ('name', 'mode', 'graph')}
    job_body = {'requestId': 'custom-job-123', 'worker': wid, 'template': 'draft-123', 'workflow': workflow, 'values': {'steps': 2, 'ckpt_name': 'b.safetensors'}}
    response = c.post('/v1/jobs', headers=headers['mobile'], json=job_body)
    assert response.status_code == 201, response.text
    job = response.json()
    assert job['payload']['workflow'] == workflow
    assert c.post('/v1/jobs', headers=headers['mobile'], json=job_body).json()['id'] == job['id']
    job_body['values']['steps'] = 3
    assert c.post('/v1/jobs', headers=headers['mobile'], json=job_body).status_code == 409
    public = TestClient(create_app(tmp_path, mobile_only=True))
    assert public.post('/v1/workflows/prepare', headers=headers['mobile'], json=body).status_code == 200
    assert public.get('/object_info', headers=headers['mobile']).status_code == 404


def test_agent_revalidates_files_using_local_metadata(tmp_path, info, graph):
    from toolcase.agent import Agent
    agent = Agent.__new__(Agent)
    agent.state_root = tmp_path
    agent.refresh_metadata = lambda force=False: info
    graph['1']['inputs']['ckpt_name'] = 'not-on-this-computer.safetensors'
    with pytest.raises(ValueError, match='允许的选项'):
        agent.process({'id': 'a'*32, 'payload': {'template': 'draft-1', 'values': {}, 'workflow': {'name': 'Untrusted broker payload', 'mode': 't2i', 'graph': graph}}, 'cancel': False})


def test_canvas_import_preserves_widget_order_after_seed_control(info, graph):
    canvas = {'nodes': [], 'links': []}
    for node_id, node in graph.items():
        slots, widgets = [], []
        for key, spec in info[node['class_type']]['input']['required'].items():
            value = node['inputs'][key]
            if isinstance(value, list):
                link_id = len(canvas['links']) + 1
                canvas['links'].append([link_id, int(value[0]), value[1], int(node_id), len(slots), spec[0]])
                slots.append({'name': key, 'link': link_id})
            else:
                widgets.append(value)
                if key == 'seed': widgets.append('randomize')
        canvas['nodes'].append({'id': int(node_id), 'type': node['class_type'], 'inputs': slots, 'widgets_values': widgets})
    template = prepare_workflow(canvas, node_catalog(info))
    compiled = compile_workflow(template, {}, None, 'canvas-import')
    assert compiled['5']['inputs']['steps'] == 4
    assert compiled['5']['inputs']['sampler_name'] == 'euler'
    assert compiled['5']['inputs']['positive'] == ['2', 0]
    assert compiled['7']['inputs']['filename_prefix'] == 'Toolcase/canvas-import'


@pytest.mark.parametrize('invalid_class', [[], {}, None])
def test_invalid_node_class_is_a_validation_error(info, graph, invalid_class):
    graph['1']['class_type'] = invalid_class
    with pytest.raises(ValueError, match='尚未开放手机编辑'):
        prepare_workflow(graph, node_catalog(info))
