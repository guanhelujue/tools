from toolcase.workflows import node_catalog, NODE_MODULES


def test_catalog_carries_explicit_widget_order_and_flags():
    info = {"KSampler": {
        "python_module": NODE_MODULES["KSampler"], "output": ["LATENT"],
        "input": {"required": {
            "steps": ["INT", {"default": 20, "forceInput": True}],
            "seed": ["INT", {"default": 123, "control_after_generate": True}],
            "model": ["MODEL"],
        }},
        "input_order": {"required": ["model", "seed", "steps"]},
    }}
    schema = node_catalog(info)["KSampler"]
    assert schema["inputOrder"] == ["model", "seed", "steps"]
    assert schema["inputs"]["seed"]["controlAfterGenerate"] is True
    assert schema["inputs"]["steps"]["forceInput"] is True
    assert schema["uiImportSupported"] is True


def test_unmapped_dynamic_widgets_are_flagged_without_expanding_execution_policy():
    info = {"KSampler": {
        "python_module": NODE_MODULES["KSampler"], "output": ["LATENT"],
        "input": {"required": {"dynamic": ["COMFY_DYNAMICCOMBO_V3", {}]}},
    }, "UnreviewedPlugin": {"input": {}, "output": []}}
    catalog = node_catalog(info)
    assert catalog["KSampler"]["uiImportSupported"] is False
    assert "UnreviewedPlugin" not in catalog
