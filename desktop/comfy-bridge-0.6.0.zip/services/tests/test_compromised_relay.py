"""Exercise the PC executor directly: these tests bypass broker authentication."""
import copy
import io
import json
import threading
from types import SimpleNamespace

import httpx
import pytest
from fastapi.testclient import TestClient
from PIL import Image

from test_editable_workflows import info, graph
from toolcase.agent import Agent
from toolcase.broker import create_app
from toolcase.local_share import tunnel_command
from toolcase.safety import clean_reference, model_filename, own_output, bounded_json, require_supported_runtime
from toolcase.templates import TemplateRegistry
from toolcase.workflows import node_catalog, prepare_workflow

JOB = 'a' * 32
PROMPT = '12345678-1234-1234-1234-123456789012'


def task(graph):
    return {'id': JOB, 'cancel': False, 'payload': {
        'requestId': 'test-request', 'worker': 'pc', 'template': 'draft-1', 'values': {},
        'workflow': {'name': 'Untrusted relay task', 'mode': 't2i', 'graph': copy.deepcopy(graph)}}}


@pytest.fixture
def executor(tmp_path, info):
    agent = Agent.__new__(Agent)
    agent.state_root = tmp_path
    agent.stop = threading.Event()
    agent.refresh_metadata = lambda force=False: info
    agent.registry = TemplateRegistry(tmp_path / 'templates')
    calls, posted = [], []
    image = io.BytesIO()
    Image.new('RGB', (32, 32), 'green').save(image, 'PNG')
    def transport(request):
        calls.append((request.method, request.url.host, request.url.path))
        path = request.url.path
        if request.url.host == 'relay.invalid':
            if request.method == 'GET': return httpx.Response(200, json={'cancel': False, 'artifacts': []})
            return httpx.Response(200, json={'ok': True})
        if path == '/prompt':
            posted.append(json.loads(request.content))
            return httpx.Response(200, json={'prompt_id': PROMPT})
        if path == '/history/' + PROMPT:
            return httpx.Response(200, json={PROMPT: {'status': {'status_str': 'success'}, 'outputs': {'7': {
                'images': [{'filename': JOB + '_00001_.png', 'subfolder': 'Toolcase', 'type': 'output'}]}}}})
        if path == '/view': return httpx.Response(200, content=image.getvalue())
        if path == '/queue': return httpx.Response(200, json={'queue_running': [], 'queue_pending': []})
        if path == '/free': return httpx.Response(200, json={})
        if path == '/system_stats': return httpx.Response(200, json={'devices': [{'torch_vram_total': 0, 'torch_vram_free': 0}]})
        raise AssertionError('Unexpected PC operation: ' + path)
    agent.cloud = httpx.Client(base_url='https://relay.invalid', transport=httpx.MockTransport(transport))
    agent.comfy = httpx.Client(base_url='http://127.0.0.1:8188', transport=httpx.MockTransport(transport))
    yield SimpleNamespace(agent=agent, calls=calls, posted=posted, info=info)
    agent.cloud.close(); agent.comfy.close()


@pytest.mark.parametrize('attack', ['command', 'url', 'python_node', 'manager_node', 'file_node', 'pickle',
                                   'local_path', 'hidden_file', 'extra_workflow_key', 'oversize', 'nonfinite'])
def test_malicious_relay_rejected_before_comfy_or_file_io(executor, graph, attack):
    job = task(graph)
    p = job['payload']; g = p['workflow']['graph']
    if attack == 'command': p['command'] = 'cmd.exe'
    if attack == 'url': p['comfy'] = 'http://192.168.1.1/'
    if attack == 'python_node': g['1']['class_type'] = 'PythonExecute'
    if attack == 'manager_node': g['1']['class_type'] = 'ManagerInstall'
    if attack == 'file_node': g['1']['class_type'] = 'ReadTextFile'
    if attack == 'pickle': g['1']['inputs']['ckpt_name'] = 'weights.ckpt'
    if attack == 'local_path': g['1']['inputs']['ckpt_name'] = 'C:/Users/example/private.safetensors'
    if attack == 'hidden_file': g['7']['inputs']['path'] = '../../private'
    if attack == 'extra_workflow_key': p['workflow']['install'] = 'untrusted-plugin'
    if attack == 'oversize': p['values']['prompt'] = 'x' * 260000
    if attack == 'nonfinite': p['values']['cfg'] = float('nan')
    with pytest.raises(ValueError): executor.agent.process(job)
    assert executor.calls == []
    assert not list(executor.agent.state_root.iterdir())


def test_spoofing_builtin_name_from_other_module_is_rejected(executor, graph):
    executor.info['CheckpointLoaderSimple']['python_module'] = 'custom_nodes.unreviewed'
    with pytest.raises(ValueError, match='尚未开放手机编辑'): executor.agent.process(task(graph))
    assert executor.calls == []


def test_builtin_template_also_requires_fresh_local_policy(executor, graph):
    executor.agent.registry.templates['local'] = {'id': 'local', 'name': 'Local', 'mode': 't2i', 'workflow': graph}
    executor.info['KSampler']['python_module'] = 'custom_nodes.unreviewed'
    job = task(graph); job['payload'].pop('workflow'); job['payload']['template'] = 'local'
    with pytest.raises(ValueError, match='尚未开放手机编辑'): executor.agent.process(job)
    assert executor.calls == []


def test_valid_generation_is_scoped_and_cannot_be_replayed_with_other_values(executor, graph):
    job = task(graph)
    # Command-looking text remains a literal prompt, never an instruction to the host.
    job['payload']['values']['prompt'] = 'A painted sign saying powershell.exe'
    executor.agent.process(job)
    assert len(executor.posted) == 1
    submitted = executor.posted[0]['prompt']
    assert submitted['7']['inputs']['filename_prefix'] == 'Toolcase/' + JOB
    assert submitted['2']['inputs']['text'] == job['payload']['values']['prompt']
    assert {path for method, host, path in executor.calls if host == '127.0.0.1'} == {'/prompt', '/history/' + PROMPT, '/view', '/queue', '/free', '/system_stats'}
    executor.calls.clear()
    executor.agent.process(job)
    assert executor.calls == []  # completed replay cannot consume GPU again
    job['payload']['values']['prompt'] = 'changed by relay'
    with pytest.raises(ValueError, match='任务内容与本机记录不一致'): executor.agent.process(job)
    assert executor.calls == []


@pytest.mark.parametrize('name', ['model.ckpt', 'model.pt', 'model.pth', 'model.bin', '../a.safetensors',
                                 'C:\\a.safetensors', '\\\\server\\a.gguf', 'https://host/model.safetensors',
                                 'folder/../a.gguf', 'model.safetensors:stream', 'bad\x00.gguf'])
def test_unsafe_model_entries_are_not_permissions(name):
    assert not model_filename(name, 'unet_name')


def test_known_files_and_pixel_vae_remain_usable(info):
    assert model_filename('subfolder/model.safetensors', 'unet_name')
    assert model_filename('model.gguf', 'unet_name')
    assert model_filename('pixel_space', 'vae_name')
    assert not model_filename('pixel_space', 'ckpt_name')
    info['CheckpointLoaderSimple']['input']['required']['ckpt_name'][0] += ['untrusted.ckpt']
    choices = node_catalog(info)['CheckpointLoaderSimple']['inputs']['ckpt_name']['options']
    assert choices == ['a.safetensors', 'b.safetensors']


@pytest.mark.parametrize('change', [{'subfolder': 'private'}, {'subfolder': '../Toolcase'},
                                    {'type': 'input'}, {'filename': 'other_00001_.png'},
                                    {'filename': '../' + JOB + '_00001_.png'}])
def test_only_this_job_output_can_be_read(change):
    item = {'filename': JOB + '_00001_.png', 'subfolder': 'Toolcase', 'type': 'output'}
    assert own_output(item, JOB) == item
    with pytest.raises(ValueError): own_output(item | change, JOB)


def test_reference_is_decoded_and_reencoded_even_if_broker_is_untrusted():
    source = io.BytesIO()
    Image.new('RGB', (32, 32), 'red').save(source, 'PNG')
    clean = clean_reference(source.getvalue() + b'REMOVE_REMOTE_TRAILING_PAYLOAD')
    assert b'REMOVE_REMOTE_TRAILING_PAYLOAD' not in clean
    with Image.open(io.BytesIO(clean)) as image:
        assert image.format == 'JPEG' and image.size == (32, 32)
    with pytest.raises((ValueError, OSError)): clean_reference(b'not an image')


def test_relay_json_is_bounded_before_parsing():
    with httpx.Client(transport=httpx.MockTransport(lambda _: httpx.Response(200, content=b' ' * 1000001))) as client:
        with pytest.raises(ValueError, match='响应超过'): bounded_json(client, 'GET', 'https://relay.invalid/job')


def test_public_gateway_never_exposes_desktop_or_comfy_admin(tmp_path):
    app = create_app(tmp_path, mobile_only=True)
    phone = app.state.store.pair(app.state.store.create_pairing('mobile'), 'attacker with valid phone token')
    headers = {'Authorization': 'Bearer ' + phone['token']}
    client = TestClient(app)
    for route in ['/prompt', '/ws', '/upload/image', '/view', '/history', '/queue', '/interrupt',
                  '/free', '/object_info', '/manager/install', '/customnode/install', '/manager/reboot',
                  '/userdata', '/exec', '/shell', '/terminal', '/screen', '/keyboard', '/mouse',
                  '/v1/worker/claim', '/v1/worker/catalog']:
        for method in ('GET', 'POST', 'PUT', 'DELETE'):
            assert client.request(method, route, headers=headers, content=b'{}').status_code == 404


def test_ssh_has_no_agent_x11_or_local_command_forwarding(tmp_path):
    command = tunnel_command('ssh', tmp_path)
    for option in ('ForwardAgent=no', 'ForwardX11=no', 'PermitLocalCommand=no', 'IdentityAgent=none'):
        assert option in command
    assert command[command.index('-R') + 1] == '80:127.0.0.1:8788'
    assert '-L' not in command and '-D' not in command


def test_unsafe_image_runtime_cannot_start_public_listener(tmp_path, monkeypatch):
    import PIL
    monkeypatch.setattr(PIL, '__version__', '11.3.0')
    with pytest.raises(RuntimeError, match='版本过旧'): create_app(tmp_path, mobile_only=True)
    with pytest.raises(RuntimeError, match='版本过旧'): require_supported_runtime()


def test_reference_decoder_does_not_dispatch_to_other_format_plugins():
    source = io.BytesIO()
    Image.new('RGB', (32, 32), 'red').save(source, 'BMP')
    with pytest.raises(OSError): clean_reference(source.getvalue())
