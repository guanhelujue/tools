ComfyUI bridge 0.6.0
See docs/COMFY_COMPUTER_WORKFLOWS.md for setup and upgrade.
Merge services/ and scripts/ into the existing Toolcase folder, preserving .local-share and .venv.
Never unpack into the ComfyUI installation. Python dependencies: services/requirements.txt.
Tests require pytest in addition to runtime dependencies.
