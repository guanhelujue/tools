param([string]$Python = 'python', [switch]$Anonymous)
$ErrorActionPreference = 'Stop'
$project = Split-Path -Parent $PSScriptRoot
Set-Location (Join-Path $project 'services')
$env:PYTHONUTF8 = '1'
$tunnelArgs = @('-m', 'toolcase.local_share')
if ($Anonymous) { $tunnelArgs += '--anonymous' }
& $Python @tunnelArgs
