param([string]$Python = 'python')
$ErrorActionPreference = 'Stop'
$project = Split-Path -Parent $PSScriptRoot
$services = Join-Path $project 'services'
$data = Join-Path $project '.local-share'
if (-not (Test-Path -LiteralPath (Join-Path $data 'data\broker.sqlite3'))) {
    throw 'Run start-tunnel.ps1 once to set the access password before background startup.'
}
if (Get-NetTCPConnection -LocalPort 8787,8788 -State Listen -ErrorAction SilentlyContinue) {
    Write-Output 'Connection ports are already in use; no duplicate process was started.'
    return
}
$resolvedPython = (Get-Command $Python -ErrorAction Stop).Source
$env:PYTHONUTF8 = '1'
$process = Start-Process -FilePath $resolvedPython -ArgumentList '-m','toolcase.local_share' -WorkingDirectory $services -WindowStyle Hidden -RedirectStandardOutput (Join-Path $data 'launcher.log') -RedirectStandardError (Join-Path $data 'launcher-error.log') -PassThru
Write-Output "Toolcase background connection started (PID $($process.Id))."
