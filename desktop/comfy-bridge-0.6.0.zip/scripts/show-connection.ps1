$ErrorActionPreference = 'Stop'
$project = Split-Path -Parent $PSScriptRoot
$sessionFile = Join-Path $project '.local-share\current-session.json'
if (Test-Path -LiteralPath $sessionFile) {
    $connection = Get-Content -LiteralPath $sessionFile -Raw | ConvertFrom-Json
    Write-Output 'App entry name: guanhelujue'
    Write-Output "Actual address: $($connection.url)"
    Write-Output 'Use your existing password. The connection has no one-hour timeout.'
} else {
    Write-Output 'Not connected yet. Wait for the network reconnect, or start the connection first.'
}
