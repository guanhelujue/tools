ComfyUI bridge 0.6.1: MOSS workflow support
See docs/comfy-moss-0.6.1.md and docs/comfy-2.1.0.md for setup.
Merge services/ and scripts/ into the existing Toolcase folder, preserving .local-share and .venv.
Never unpack into the ComfyUI installation. Runtime dependencies: services/requirements.txt.
Tests additionally require pytest.
