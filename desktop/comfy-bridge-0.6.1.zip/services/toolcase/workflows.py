"""Mobile-editable Comfy graphs with local node, file-choice and resource validation.

The phone may wire these generation nodes, but never install code, load arbitrary
computer files, run API/payment nodes, or choose an output filesystem location.
The broker checks the published schema; the agent checks fresh local metadata again.
"""
import copy
import json
import math
import re
import secrets

from .contracts import MODES, validate_values
from .import_workflows import graph_to_api
from .safety import model_filename

# Exact implementation modules observed in the supported local ComfyUI build.
# A plugin taking over a core class name is not automatically trusted.
NODE_MODULES = {}
for _module, _names in {
    "nodes": "CheckpointLoaderSimple UNETLoader CLIPLoader DualCLIPLoader VAELoader LoraLoader LoraLoaderModelOnly CLIPTextEncode ConditioningZeroOut ConditioningCombine ConditioningConcat ConditioningSetTimestepRange EmptyLatentImage KSampler KSamplerAdvanced VAEEncode VAEEncodeTiled VAEDecode VAEDecodeTiled LoadImage SaveImage PreviewImage ImageScale ImageScaleBy SetLatentNoiseMask",
    "comfy_extras.nodes_custom_sampler": "KSamplerSelect SamplerCustomAdvanced RandomNoise CFGGuider BasicGuider BasicScheduler",
    "comfy_extras.nodes_flux": "EmptyFlux2LatentImage Flux2Scheduler FluxGuidance",
    "comfy_extras.nodes_sd3": "EmptySD3LatentImage",
    "comfy_extras.nodes_slg": "SkipLayerGuidanceDiTSimple",
    "comfy_extras.nodes_hunyuan": "EmptyHunyuanLatentVideo",
    "comfy_extras.nodes_model_advanced": "ModelSamplingAuraFlow ModelSamplingFlux ModelSamplingSD3",
    "comfy_extras.nodes_clip_sdxl": "CLIPTextEncodeSDXL",
    "comfy_extras.nodes_edit_model": "ReferenceLatent",
    "comfy_extras.nodes_audio": "VAEDecodeAudio",
    "comfy_extras.nodes_video": "SaveVideo CreateVideo",
    "comfy_extras.nodes_post_processing": "ImageSharpen ImageBlur",
    "comfy_extras.nodes_images": "ImageCrop",
    "comfy_extras.nodes_mask": "ImageCompositeMasked GrowMask SolidMask ImageToMask MaskToImage",
    "comfy_extras.nodes_compositing": "SplitImageWithAlpha",
    "comfy_extras.nodes_minimax_h3": "MiniMaxH3ImageToVideo MiniMaxH3AddGuide",
    "comfy_extras.nodes_wan": "Wan22ImageToVideoLatent",
    "comfy_extras.nodes_qwen": "TextEncodeQwenImage21 QwenImage21Cache",
    "custom_nodes.ComfyUI-GGUF": "UnetLoaderGGUF CLIPLoaderGGUF DualCLIPLoaderGGUF",
}.items():
    NODE_MODULES.update(dict.fromkeys(_names.split(), _module))
SAFE_NODES = frozenset(NODE_MODULES)
SCALARS = {"INT", "FLOAT", "STRING", "BOOLEAN", "CHOICE"}
FILES = {"ckpt_name", "unet_name", "clip_name", "clip_name1", "clip_name2", "vae_name", "lora_name"}
LABELS = {"ckpt_name": "Checkpoint 模型", "unet_name": "扩散模型", "clip_name": "文本编码器", "clip_name1": "文本编码器 1",
          "clip_name2": "文本编码器 2", "vae_name": "VAE", "lora_name": "LoRA", "type": "编码器架构",
          "text": "提示词", "prompt": "提示词", "negative_prompt": "负面提示词", "width": "宽度", "height": "高度",
          "length": "视频帧数", "steps": "采样步数", "seed": "种子（-1 随机）", "noise_seed": "种子（-1 随机）",
          "cfg": "CFG 引导", "denoise": "重绘幅度", "sampler_name": "采样器", "scheduler": "调度器",
          "strength_model": "模型 LoRA 强度", "strength_clip": "文本 LoRA 强度", "batch_size": "生成数量",
          "fps": "帧率", "shift": "采样偏移", "guidance": "引导强度", "device": "加载设备", "weight_dtype": "模型精度"}


def node_catalog(info):
    result = {}
    for name in sorted(SAFE_NODES & info.keys()):
        raw = info[name]
        if raw.get("api_node") or raw.get("python_module") != NODE_MODULES[name]:
            continue
        inputs, invalid_schema, dynamic_widgets = {}, False, False
        for group in ("required", "optional"):
            group_inputs = raw.get("input", {}).get(group, {})
            declared_order = raw.get("input_order", {}).get(group, [])
            order = [key for key in declared_order if key in group_inputs]
            order.extend(key for key in group_inputs if key not in order)
            for key in order:
                spec = group_inputs[key]
                kind = spec[0]
                opts = spec[1] if len(spec) > 1 and isinstance(spec[1], dict) else {}
                if kind == "COMFY_AUTOGROW_V3":
                    # Qwen 2.1 reference image sockets are flattened by Comfy's API.
                    for socket in opts.get("template", {}).get("names", [])[:16]:
                        inputs[key + "." + socket] = {"kind": "IMAGE", "required": False}
                    continue
                if kind == "COMFY_DYNAMICCOMBO_V3":
                    dynamic_widgets = True
                    continue
                entry = {"kind": "CHOICE" if isinstance(kind, list) or kind == "COMBO" else kind,
                         "required": group == "required"}
                if opts.get("forceInput"):
                    entry["forceInput"] = True
                if opts.get("control_after_generate"):
                    entry["controlAfterGenerate"] = True
                if entry["kind"] == "CHOICE":
                    entry["options"] = kind if isinstance(kind, list) else opts.get("options", [])
                    entry["default"] = opts.get("default", entry["options"][0] if entry["options"] else "")
                elif entry["kind"] in SCALARS:
                    entry["default"] = opts.get("default", False if kind == "BOOLEAN" else "" if kind == "STRING" else 0)
                    if kind in {"INT", "FLOAT"}:
                        entry.update(min=opts.get("min", -10000), max=opts.get("max", 10000), step=opts.get("step", 1 if kind == "INT" else 0))
                        ceilings = {"width": 2048, "height": 2048, "target_width": 2048, "target_height": 2048,
                                    "length": 260, "batch_size": 4, "steps": 80, "start_at_step": 80, "end_at_step": 80,
                                    "fps": 60, "scale_by": 2, "resolution": 2048}
                        if key in ceilings:
                            entry["max"] = min(entry["max"], ceilings[key])
                        if key in {"seed", "noise_seed"}:
                            entry.update(min=-1, max=2**53 - 1, step=1)
                if key in FILES:
                    if entry["kind"] != "CHOICE":
                        invalid_schema = True
                    else:
                        entry["options"] = [v for v in entry["options"] if model_filename(v, key)]
                        if entry["default"] not in entry["options"]:
                            entry["default"] = entry["options"][0] if entry["options"] else ""
                inputs[key] = entry
        if invalid_schema:
            continue
        if name == "LoadImage":
            # Do not disclose or select computer-side input files.
            inputs = {"image": {"kind": "STRING", "required": True, "default": "toolcase-reference", "locked": True}}
        if name in {"SaveImage", "SaveVideo"}:
            inputs["filename_prefix"] = {"kind": "STRING", "required": True, "default": "Toolcase/result", "locked": True}
        if name == "SaveVideo":
            inputs = {key: value for key, value in inputs.items() if key in {"video", "filename_prefix"}}
            for key, value in {"format": "mp4", "format.codec": "h264", "format.codec.encoding": "auto"}.items():
                inputs[key] = {"kind": "STRING", "required": True, "default": value, "locked": True}
        result[name] = {"displayName": raw.get("display_name") or name, "inputs": inputs, "outputs": raw.get("output", []),
                        "inputOrder": list(inputs), "uiImportSupported": not dynamic_widgets or name == "SaveVideo"}
    return result


def inventory_from_info(info):
    groups = {
        "checkpoints": [("CheckpointLoaderSimple", "ckpt_name")],
        "diffusion": [("UNETLoader", "unet_name"), ("UnetLoaderGGUF", "unet_name")],
        "textEncoders": [("CLIPLoader", "clip_name"), ("CLIPLoaderGGUF", "clip_name")],
        "loras": [("LoraLoader", "lora_name"), ("LoraLoaderModelOnly", "lora_name")], "vaes": [("VAELoader", "vae_name")],
    }
    result = {}
    for group, loaders in groups.items():
        items = {}
        for node, field in loaders:
            if info.get(node, {}).get("python_module") != NODE_MODULES.get(node):
                continue
            values = info.get(node, {}).get("input", {}).get("required", {}).get(field, [[]])[0]
            if isinstance(values, list):
                for value in values:
                    if not model_filename(value, field):
                        continue
                    items.setdefault(str(value), {"name": str(value), "loader": node})
        result[group] = list(items.values())
    return result


def native_info(nodes):
    """Reconstruct the widget subset for ordinary LiteGraph JSON imports."""
    result = {}
    for name, node in nodes.items():
        groups = {"required": {}, "optional": {}}
        for key, spec in node["inputs"].items():
            kind = spec["options"] if spec["kind"] == "CHOICE" else spec["kind"]
            opts = {k: spec[k] for k in ("default", "min", "max", "step") if k in spec}
            if key in {"seed", "noise_seed"}:
                opts["control_after_generate"] = True
            groups["required" if spec["required"] else "optional"][key] = [kind, opts]
        result[name] = {"input": groups}
    return result


def normalize_graph(graph, nodes):
    if not isinstance(graph, dict) or len(json.dumps(graph, ensure_ascii=False)) > 220000:
        raise ValueError("工作流 JSON 无效或超过 220 KB")
    if isinstance(graph.get("prompt"), dict):
        graph = graph["prompt"]
    if "nodes" in graph:
        if not isinstance(graph["nodes"], list) or len(graph["nodes"]) > 120:
            raise ValueError("工作流最多 120 个节点")
        try:
            graph = graph_to_api(graph, native_info(nodes))
        except (KeyError, TypeError, IndexError) as exc:
            raise ValueError("无法读取此画布格式，请在 ComfyUI 导出 API 格式 JSON") from exc
    if not graph or len(graph) > 120:
        raise ValueError("工作流需要 1–120 个节点")
    clean = {}
    for key, node in graph.items():
        if not isinstance(key, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,40}", key) or not isinstance(node, dict):
            raise ValueError("节点编号或结构不正确")
        name = node.get("class_type")
        if not isinstance(name, str) or name not in SAFE_NODES or name not in nodes:
            raise ValueError(f"节点 {key}：{name} 尚未开放手机编辑；请使用支持的生成节点")
        raw_inputs = node.get("inputs", {})
        if not isinstance(raw_inputs, dict):
            raise ValueError(f"节点 {key} 输入必须是对象")
        specs = nodes[name]["inputs"]
        if set(raw_inputs) - specs.keys():
            raise ValueError(f"节点 {key} 包含未知输入：{', '.join(sorted(set(raw_inputs) - specs.keys()))}")
        inputs = copy.deepcopy(raw_inputs)
        for field, spec in specs.items():
            if spec.get("locked"):
                inputs[field] = spec["default"]
            elif field not in inputs and spec.get("required"):
                raise ValueError(f"节点 {key} 缺少输入 {LABELS.get(field, field)}")
        title = str(node.get("_meta", {}).get("title", name))[:80] if isinstance(node.get("_meta", {}), dict) else name
        clean[key] = {"class_type": name, "inputs": inputs, "_meta": {"title": title}}
    return clean


def field_for(node_id, key, value, spec, name, used):
    canonical = "seed" if key == "noise_seed" else "prompt" if key in {"text", "prompt"} else key
    field_id = canonical if canonical not in used and re.fullmatch(r"[a-zA-Z0-9_]{1,40}", canonical) else f"n{node_id}_{key}"
    used.add(field_id)
    kind = spec["kind"]
    group = "model" if key in FILES - {"lora_name"} or key in {"type", "device", "weight_dtype"} else "lora" if "Lora" in name else "prompt" if kind == "STRING" else "advanced"
    label = LABELS.get(key, key)
    f = {"id": field_id, "label": f"{label} · #{node_id}", "kind": {"INT": "int", "FLOAT": "float", "STRING": "text", "BOOLEAN": "bool", "CHOICE": "choice"}[kind],
         "group": group, "default": value, "nodeId": node_id, "inputName": key, "binds": [[node_id, key]]}
    if kind == "CHOICE":
        f["mapping"] = {str(v): v for v in spec["options"]}
        f["options"] = [{"id": str(v), "label": str(v)} for v in spec["options"]]
        f["default"] = str(value)
    elif kind in {"INT", "FLOAT"}:
        f.update({k: spec[k] for k in ("min", "max", "step")})
    elif kind == "STRING":
        f["maxLength"] = 8000
    return f


def prepare_workflow(graph, nodes, name="我的工作流", mode="t2i", template_id="custom"):
    if not isinstance(mode, str) or mode not in MODES or not isinstance(name, str) or not 1 <= len(name.strip()) <= 80:
        raise ValueError("请填写工作流名称并选择生成模式")
    graph = normalize_graph(graph, nodes)
    fields, used, image_nodes, output_nodes = [], set(), [], []
    dependencies = {}
    for node_id, node in graph.items():
        node_name = node["class_type"]
        specs = nodes[node_name]["inputs"]
        dependencies[node_id] = []
        for key, value in node["inputs"].items():
            spec = specs[key]
            kind = spec["kind"]
            if kind in SCALARS:
                if isinstance(value, (list, dict)) or value is None:
                    raise ValueError(f"节点 {node_id}.{key} 需要直接填写参数")
                if not spec.get("locked"):
                    fields.append(field_for(node_id, key, value, spec, node_name, used))
            else:
                if not isinstance(value, list) or len(value) != 2 or not isinstance(value[0], str) or type(value[1]) is not int:
                    raise ValueError(f"节点 {node_id}.{key} 需要连接节点输出")
                source, port = value
                if source not in graph:
                    raise ValueError(f"节点 {node_id}.{key} 的来源节点不存在")
                outputs = nodes[graph[source]["class_type"]]["outputs"]
                if not 0 <= port < len(outputs) or outputs[port] != kind:
                    raise ValueError(f"节点 {node_id}.{key} 连接类型不匹配，需要 {kind}")
                dependencies[node_id].append(source)
        if node_name == "LoadImage":
            image_nodes.append(node_id)
        if node_name in {"SaveImage", "SaveVideo"}:
            output_nodes.append(node_id)
    if not output_nodes or len(output_nodes) > 8:
        raise ValueError("需要 1–8 个保存图片或视频节点")
    if bool(image_nodes) != mode.startswith("i"):
        raise ValueError("图生模式需要 LoadImage 参考图节点；文生模式请移除该节点或改选图生模式")
    if mode.endswith("v") != any(graph[k]["class_type"] == "SaveVideo" for k in output_nodes):
        raise ValueError("生成模式与保存图片/视频节点不一致")
    visiting, visited = set(), set()
    def visit(key):
        if key in visiting:
            raise ValueError("工作流存在循环连线")
        if key in visited:
            return
        visiting.add(key)
        for source in dependencies[key]:
            visit(source)
        visiting.remove(key); visited.add(key)
    for key in graph:
        visit(key)
    template = {"id": template_id, "name": name.strip(), "mode": mode, "description": "可编辑节点、模型、LoRA 与参数的工作流", "maxPixels": 2048 * 2048,
                "requiresImage": bool(image_nodes), "fields": fields, "workflow": graph, "imageNodes": image_nodes, "outputNodes": output_nodes}
    validate_values(template, {f["id"]: f["default"] for f in fields})
    check_resources(graph)
    return template


def check_resources(graph):
    scale_product = 1.0
    for node in graph.values():
        v = node["inputs"]
        if node["class_type"] == "ImageScaleBy":
            scale_product *= max(1.0, v["scale_by"])
            if scale_product > 4:
                raise ValueError("工作流累计放大倍率最多 4 倍")
        if v.get("width", 1) * v.get("height", 1) > 2048 * 2048:
            raise ValueError("单幅画面最多 409 万像素")
        if v.get("width", 1) * v.get("height", 1) * v.get("length", 1) > 1024 * 1024 * 260:
            raise ValueError("视频分辨率与帧数乘积超过本机上限")


def public_template(template):
    return {k: v for k, v in template.items() if k not in {"workflow", "fields", "imageNodes", "outputNodes"}} | {
        "graph": copy.deepcopy(template["workflow"]),
        "fields": [{k: v for k, v in f.items() if k not in {"binds", "mapping"}} for f in template["fields"]]}


def compile_workflow(template, values, reference, job_id):
    values = validate_values(template, values)
    graph = copy.deepcopy(template["workflow"])
    for field in template["fields"]:
        value = values[field["id"]]
        if field["kind"] == "choice":
            value = field["mapping"][value]
        if field["inputName"] in {"seed", "noise_seed"} and value == -1:
            value = secrets.randbelow(2**31 - 1)
        graph[field["nodeId"]]["inputs"][field["inputName"]] = value
    for node in template["imageNodes"]:
        if not reference:
            raise ValueError("请选择并上传参考图")
        graph[node]["inputs"]["image"] = reference
    for node in template["outputNodes"]:
        graph[node]["inputs"]["filename_prefix"] = "Toolcase/" + job_id
    check_resources(graph)
    return graph
