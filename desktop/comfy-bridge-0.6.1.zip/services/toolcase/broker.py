import asyncio
import io
import json
import os
import re
import secrets
import time
from collections import defaultdict, deque
from pathlib import Path
from typing import Literal

from fastapi import FastAPI, HTTPException, Request, UploadFile, File, Depends
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse, Response
from PIL import Image, ImageOps, UnidentifiedImageError
from pydantic import BaseModel, ConfigDict, Field

from .contracts import ID_PATTERN, MODES, validate_values
from .store import Store, job_json
from .workflows import prepare_workflow, public_template, compile_workflow
from .safety import require_supported_runtime

TERMINAL = {"completed", "failed", "cancelled"}
MAX_INPUT = 20 * 1024 * 1024
MAX_OUTPUT = 300 * 1024 * 1024
MAX_STORAGE = 10 * 1024 * 1024 * 1024
Image.MAX_IMAGE_PIXELS = 20_000_000


class PairRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    code: str = Field(min_length=20, max_length=32)
    name: str = Field(min_length=1, max_length=80)


class LoginRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    password: str = Field(min_length=1, max_length=128)


class WorkflowBody(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str = Field(min_length=1, max_length=80)
    mode: Literal["t2i", "i2i", "t2v", "i2v"]
    graph: dict


class PrepareRequest(WorkflowBody):
    worker: str = Field(min_length=1, max_length=80)


class JobRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    requestId: str = Field(min_length=10, max_length=80)
    worker: str = Field(min_length=1, max_length=80)
    template: str = Field(min_length=1, max_length=80)
    values: dict
    inputId: str | None = None
    workflow: WorkflowBody | None = None


class StateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    state: Literal["running", "uploading", "completed", "failed", "cancelled"]
    message: str = Field(default="", max_length=500)


def create_app(directory=None, mobile_only=False):
    require_supported_runtime()
    store = Store(directory or os.environ.get("TOOLCASE_DATA", ".data"))
    app = FastAPI(title="Toolcase private task broker", docs_url=None, redoc_url=None, openapi_url=None)
    app.state.store = store
    attempts = defaultdict(deque)
    upload_attempts = defaultdict(deque)

    @app.exception_handler(RequestValidationError)
    async def invalid_request(request, exc):
        # Pydantic error payloads otherwise echo rejected password values.
        return JSONResponse({"detail": "请求参数格式不正确"}, status_code=422)

    @app.middleware("http")
    async def limits(request: Request, call_next):
        if mobile_only:
            path, method = request.url.path, request.method
            allowed = ((method == "GET" and path in {"/health", "/v1/catalog", "/v1/jobs"})
                       or (method == "POST" and path in {"/v1/login", "/v1/logout", "/v1/pair", "/v1/jobs", "/v1/uploads", "/v1/workflows/prepare"})
                       or (method in {"GET", "DELETE"} and re.fullmatch(r"/v1/jobs/[0-9a-f]{32}", path))
                       or (method == "POST" and re.fullmatch(r"/v1/jobs/[0-9a-f]{32}/cancel", path))
                       or (method == "GET" and re.fullmatch(r"/v1/files/[0-9a-f]{32}(?:/thumbnail)?", path)))
            if not allowed:
                return JSONResponse({"detail": "接口未开放"}, status_code=404)
        if request.url.path.startswith("/v1/") and request.url.path not in {"/v1/pair", "/v1/login"}:
            header = request.headers.get("authorization", "")
            device = store.authenticate(header[7:]) if header.startswith("Bearer ") else None
            if not device:
                return JSONResponse({"detail": "连接凭据已失效，请在设置中重新登录"}, status_code=401)
            if mobile_only and device["role"] != "mobile":
                return JSONResponse({"detail": "此入口只接受手机设备"}, status_code=403)
            request.state.device = device
        length = request.headers.get("content-length", "0")
        if request.method == "POST" and ("content-length" not in request.headers or "transfer-encoding" in request.headers):
            return JSONResponse({"detail": "请求必须声明固定长度"}, status_code=411)
        max_body = MAX_OUTPUT + 65536 if request.url.path.endswith("/artifacts") else MAX_INPUT + 65536
        if not length.isdigit() or int(length) > max_body:
            return JSONResponse({"detail": "请求体过大"}, status_code=413)
        json_limit = 1000000 if request.url.path == "/v1/worker/catalog" else 256000
        if request.headers.get("content-type", "").startswith("application/json") and int(length) > json_limit:
            return JSONResponse({"detail": "请求体过大"}, status_code=413)
        if request.url.path == "/v1/uploads":
            if request.state.device["role"] != "mobile":
                return JSONResponse({"detail": "需要手机端权限"}, status_code=403)
            queue = upload_attempts[request.state.device["id"]]
            now = time.time()
            while queue and queue[0] < now - 60:
                queue.popleft()
            if len(queue) >= 10:
                return JSONResponse({"detail": "参考图上传过于频繁"}, status_code=429)
            queue.append(now)
        if request.url.path.startswith("/v1/worker/") and request.url.path.endswith("/artifacts") and request.state.device["role"] != "worker":
            return JSONResponse({"detail": "需要执行器权限"}, status_code=403)
        response = await call_next(request)
        response.headers["Cache-Control"] = "no-store"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Content-Security-Policy"] = "default-src 'none'; frame-ancestors 'none'"
        return response

    def auth(request: Request):
        if hasattr(request.state, "device"):
            return request.state.device
        header = request.headers.get("authorization", "")
        if not header.startswith("Bearer "):
            raise HTTPException(401, "请先配对设备")
        device = store.authenticate(header[7:])
        if not device:
            raise HTTPException(401, "配对凭据已失效")
        return device

    def mobile(device=Depends(auth)):
        if device["role"] != "mobile":
            raise HTTPException(403, "需要手机端权限")
        return device

    def worker(device=Depends(auth)):
        if device["role"] != "worker":
            raise HTTPException(403, "需要执行器权限")
        return device

    def own_job(db, job_id, device, include_deleted=False):
        key = "worker" if device["role"] == "worker" else "requester"
        row = db.execute(f"SELECT * FROM jobs WHERE id=? AND {key}=?", (job_id, device["id"])).fetchone()
        if not row or (row['deleted'] and device['role'] == 'mobile' and not include_deleted):
            raise HTTPException(404, "任务不存在")
        return row

    @app.get("/health")
    def health():
        return {"service": "toolcase", "version": "0.6.1", "policy": "generation-only-v1"}

    @app.post("/v1/login")
    def login(body: LoginRequest):
        result, retry_after = store.login(body.password)
        if retry_after:
            raise HTTPException(429, f"口令尝试过多，请 {retry_after} 秒后重试", headers={"Retry-After": str(retry_after)})
        if not result:
            raise HTTPException(401, "访问口令不正确，或电脑端尚未设置口令")
        return result

    @app.post("/v1/logout")
    def logout(request: Request, device=Depends(mobile)):
        store.logout(request.headers['authorization'][7:])
        return {"ok": True}

    @app.post("/v1/pair")
    def pair(body: PairRequest, request: Request):
        address = request.client.host if request.client else "unknown"
        now = time.time()
        if len(attempts) > 10000:
            attempts.clear()
        queue = attempts[address]
        while queue and queue[0] < now - 60:
            queue.popleft()
        if len(queue) >= 8:
            raise HTTPException(429, "尝试过多，请一分钟后再试")
        queue.append(now)
        result = store.pair(body.code, body.name, required_role="mobile" if mobile_only else None)
        if not result:
            raise HTTPException(401, "配对码已使用、过期或不正确")
        return result

    @app.get("/v1/catalog")
    def catalog(device=Depends(mobile)):
        with store.db() as db:
            rows = db.execute("SELECT c.*, d.name FROM catalogs c JOIN devices d ON c.worker=d.id WHERE d.revoked=0 ORDER BY c.seen DESC").fetchall()
        return {"workers": [{"id": r["worker"], "name": r["name"], "online": time.time() - r["seen"] < 45,
                             "lastSeen": r["seen"], **json.loads(r["payload"])} for r in rows]}

    @app.post("/v1/worker/catalog")
    def set_catalog(body: dict, device=Depends(worker)):
        templates = body.get("templates", [])
        if len(templates) > 40 or len(json.dumps(body, ensure_ascii=False)) > 950000:
            raise HTTPException(400, "目录过大")
        for template in templates:
            if not ID_PATTERN.fullmatch(template.get("id", "")) or template.get("mode") not in MODES:
                raise HTTPException(400, "无效工作流目录")
            try:
                validate_values(template, {f["id"]: f["default"] for f in template["fields"]})
            except (KeyError, TypeError, ValueError) as exc:
                raise HTTPException(400, "工作流参数配置不合法") from exc
        safe = {"templates": templates, "gpu": str(body.get("gpu", ""))[:120], "comfyOnline": bool(body.get("comfyOnline", False))}
        safe.update(nodes=body.get("nodes", {}), inventory=body.get("inventory", {}),
                    catalogErrors=body.get("catalogErrors", []), workflowEditing=bool(body.get("workflowEditing")))
        with store.db() as db:
            db.execute("INSERT INTO catalogs VALUES(?,?,?) ON CONFLICT(worker) DO UPDATE SET payload=excluded.payload, seen=excluded.seen",
                       (device["id"], json.dumps(safe, ensure_ascii=False), time.time()))
        return {"ok": True}

    @app.post("/v1/worker/heartbeat")
    def heartbeat(device=Depends(worker)):
        with store.db() as db:
            db.execute("UPDATE catalogs SET seen=? WHERE worker=?", (time.time(), device["id"]))
        return {"ok": True}

    @app.post("/v1/jobs", status_code=201)
    def submit(body: JobRequest, device=Depends(mobile)):
        raw = body.model_dump()
        if body.workflow is None:
            raw.pop("workflow")
        with store.db() as db:
            db.execute("BEGIN IMMEDIATE")
            existing = db.execute("SELECT * FROM jobs WHERE request_id=?", (body.requestId,)).fetchone()
            if existing:
                if existing["requester"] != device["id"]:
                    raise HTTPException(409, "该请求编号已用于其他参数")
                if existing['deleted']:
                    raise HTTPException(410, "该任务已删除，请重新提交新任务")
                if json.loads(existing["payload"]) != raw:
                    raise HTTPException(409, "该请求编号已用于其他参数")
                return job_json(db, existing)
            active = db.execute("SELECT count(*) FROM jobs WHERE requester=? AND deleted=0 AND state NOT IN ('completed','failed','cancelled')", (device["id"],)).fetchone()[0]
            if active >= 5:
                raise HTTPException(429, "最多同时保留 5 个未完成任务")
            catalog_row = db.execute("SELECT c.payload FROM catalogs c JOIN devices d ON c.worker=d.id WHERE c.worker=? AND d.revoked=0", (body.worker,)).fetchone()
            if not catalog_row:
                raise HTTPException(400, "电脑尚未同步工作流")
            catalog_data = json.loads(catalog_row["payload"])
            template = next((t for t in catalog_data["templates"] if t["id"] == body.template), None)
            if body.workflow:
                if not ID_PATTERN.fullmatch(body.template):
                    raise HTTPException(400, "工作流编号不正确")
                try:
                    template = prepare_workflow(body.workflow.graph, catalog_data.get("nodes", {}), body.workflow.name, body.workflow.mode, body.template)
                    compile_workflow(template, body.values, "toolcase-reference" if body.inputId else None, "validation")
                except (KeyError, TypeError, ValueError) as exc:
                    raise HTTPException(400, str(exc)) from exc
            if not template:
                raise HTTPException(400, "工作流未开放")
            try:
                validate_values(template, body.values)
            except ValueError as exc:
                raise HTTPException(400, str(exc)) from exc
            if template.get("requiresImage") and not body.inputId:
                raise HTTPException(400, "需要上传参考图")
            if body.inputId and not db.execute("SELECT id FROM files WHERE id=? AND requester=? AND job IS NULL", (body.inputId, device["id"])).fetchone():
                raise HTTPException(400, "参考图不存在或不属于当前设备")
            job_id = secrets.token_hex(16)
            now = time.time()
            db.execute("INSERT INTO jobs(id,request_id,requester,worker,template,payload,state,message,created,updated) VALUES(?,?,?,?,?,?,'queued','等待电脑领取',?,?)",
                       (job_id, body.requestId, device["id"], body.worker, body.template, json.dumps(raw, ensure_ascii=False), now, now))
            return job_json(db, db.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone())

    @app.post("/v1/workflows/prepare")
    def prepare(body: PrepareRequest, device=Depends(mobile)):
        with store.db() as db:
            row = db.execute("SELECT c.payload FROM catalogs c JOIN devices d ON d.id=c.worker WHERE c.worker=? AND d.revoked=0", (body.worker,)).fetchone()
        if not row:
            raise HTTPException(400, "电脑尚未同步模型与节点")
        try:
            template = prepare_workflow(body.graph, json.loads(row["payload"]).get("nodes", {}), body.name, body.mode)
            return {"template": public_template(template)}
        except (ValueError, TypeError, KeyError) as exc:
            raise HTTPException(400, str(exc)) from exc

    @app.get("/v1/jobs")
    def jobs(device=Depends(mobile)):
        with store.db() as db:
            return {"jobs": [job_json(db, r) for r in db.execute("SELECT * FROM jobs WHERE requester=? AND deleted=0 ORDER BY created DESC LIMIT 100", (device["id"],)).fetchall()]}

    @app.get("/v1/jobs/{job_id}")
    def get_job(job_id: str, device=Depends(auth)):
        with store.db() as db:
            return job_json(db, own_job(db, job_id, device))

    @app.post("/v1/jobs/{job_id}/cancel")
    def cancel(job_id: str, device=Depends(mobile)):
        with store.db() as db:
            db.execute("BEGIN IMMEDIATE")
            row = own_job(db, job_id, device)
            if row["state"] not in TERMINAL:
                state = "cancelled" if row["state"] == "queued" else row["state"]
                db.execute("UPDATE jobs SET cancel=1,state=?,message='已请求取消',updated=? WHERE id=?", (state, time.time(), job_id))
            return job_json(db, db.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone())

    @app.delete("/v1/jobs/{job_id}")
    def delete_job(job_id: str, device=Depends(mobile)):
        with store.db() as db:
            db.execute('BEGIN IMMEDIATE')
            row = own_job(db, job_id, device, include_deleted=True)
            # Keep the request id as a tombstone so a retry cannot start a second GPU job.
            state = row['state'] if row['state'] in TERMINAL else 'cancelled'
            db.execute("UPDATE jobs SET deleted=1,cancel=1,state=?,payload='{}',template='',message='已删除',updated=? WHERE id=?", (state, time.time(), job_id))
            for artifact in db.execute('SELECT id FROM files WHERE job=?', (job_id,)).fetchall():
                (store.root / 'files' / artifact['id']).unlink(missing_ok=True)
            db.execute('DELETE FROM files WHERE job=?', (job_id,))
        return {'ok': True}

    @app.post("/v1/worker/claim")
    def claim(device=Depends(worker)):
        with store.db() as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("SELECT * FROM jobs WHERE worker=? AND deleted=0 AND state IN ('running','uploading') ORDER BY created LIMIT 1", (device["id"],)).fetchone()
            if row:
                return {"job": job_json(db, row)}
            row = db.execute("SELECT * FROM jobs WHERE worker=? AND deleted=0 AND state='queued' ORDER BY created LIMIT 1", (device["id"],)).fetchone()
            if not row:
                return {"job": None}
            db.execute("UPDATE jobs SET state='running',message='电脑已领取',updated=? WHERE id=?", (time.time(), row["id"]))
            return {"job": job_json(db, db.execute("SELECT * FROM jobs WHERE id=?", (row["id"],)).fetchone())}

    @app.post("/v1/worker/jobs/{job_id}/state")
    def set_state(job_id: str, body: StateRequest, device=Depends(worker)):
        with store.db() as db:
            db.execute('BEGIN IMMEDIATE')
            row = own_job(db, job_id, device)
            if row['deleted']:
                raise HTTPException(409, "任务已删除")
            if row["state"] in TERMINAL and row["state"] != body.state:
                raise HTTPException(409, "任务已结束")
            if body.state == "completed" and not db.execute("SELECT id FROM files WHERE job=?", (job_id,)).fetchone():
                raise HTTPException(400, "没有已保存的成品，不能标记完成")
            db.execute("UPDATE jobs SET state=?,message=?,updated=? WHERE id=?", (body.state, body.message, time.time(), job_id))
        return {"ok": True}

    async def read_limited(file: UploadFile, limit: int):
        chunks, size = [], 0
        while chunk := await file.read(1024 * 1024):
            size += len(chunk)
            if size > limit:
                raise HTTPException(413, "文件超过大小限制")
            chunks.append(chunk)
        return b"".join(chunks)

    def storage_check(db, incoming):
        total = db.execute("SELECT COALESCE(sum(size),0) FROM files").fetchone()[0]
        if total + incoming > MAX_STORAGE:
            raise HTTPException(507, "服务端文件配额已满，请在管理端清理过期成品")

    @app.post("/v1/uploads", status_code=201)
    async def upload(file: UploadFile = File(...), device=Depends(mobile)):
        data = await read_limited(file, MAX_INPUT)
        try:
            with Image.open(io.BytesIO(data), formats=["PNG", "JPEG", "WEBP"]) as img:
                if img.width * img.height > 20_000_000 or getattr(img, "n_frames", 1) != 1:
                    raise ValueError("不支持的图片")
                img.load()
                clean = ImageOps.exif_transpose(img).convert("RGB")
                buffer = io.BytesIO()
                clean.save(buffer, "JPEG", quality=95)
                data = buffer.getvalue()
        except (UnidentifiedImageError, OSError, ValueError, Image.DecompressionBombError) as exc:
            raise HTTPException(400, "仅接受有效的 PNG、JPEG 或 WebP 静态参考图（最多 2000 万像素）") from exc
        file_id = secrets.token_hex(16)
        with store.db() as db:
            db.execute("BEGIN IMMEDIATE")
            recent = db.execute("SELECT count(*) FROM files WHERE requester=? AND job IS NULL AND created>?", (device["id"], time.time()-86400)).fetchone()[0]
            if recent >= 100:
                raise HTTPException(429, "每台手机每天最多上传 100 张参考图")
            storage_check(db, len(data))
            (store.root / "files" / file_id).write_bytes(data)
            db.execute("INSERT INTO files VALUES(?,NULL,?,?,?,?,?)", (file_id, device["id"], file_id + ".jpg", "image/jpeg", len(data), time.time()))
        return {"id": file_id, "size": len(data)}

    @app.post("/v1/worker/jobs/{job_id}/artifacts", status_code=201)
    async def artifact(job_id: str, file: UploadFile = File(...), device=Depends(worker)):
        with store.db() as db:
            row = own_job(db, job_id, device)
            if row['deleted'] or row["state"] not in {"running", "uploading"}:
                raise HTTPException(409, "任务不接受成品")
            requester = row["requester"]
        name = Path(file.filename or "result.bin").name
        extension = Path(name).suffix.lower()
        types = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp", ".gif": "image/gif", ".mp4": "video/mp4", ".webm": "video/webm"}
        if extension not in types or len(name) > 180 or "/" in name or "\\" in name:
            raise HTTPException(400, "不支持的成品类型")
        file_id = secrets.token_hex(16)
        path = store.root / "files" / file_id
        size, prefix = 0, b""
        try:
            with path.open("wb") as output:
                while chunk := await file.read(1024 * 1024):
                    size += len(chunk)
                    if size > MAX_OUTPUT:
                        raise HTTPException(413, "单个成品最多 300 MiB")
                    if not prefix:
                        prefix = chunk[:32]
                    output.write(chunk)
            if size == 0:
                raise HTTPException(400, "空文件")
            if extension == ".mp4" and b"ftyp" not in prefix:
                raise HTTPException(400, "无效 MP4 文件")
            if extension == ".webm" and not prefix.startswith(b"\x1aE\xdf\xa3"):
                raise HTTPException(400, "无效 WebM 文件")
            if types[extension].startswith("image/"):
                try:
                    with Image.open(path, formats=["PNG", "JPEG", "WEBP", "GIF"]) as image:
                        image.verify()
                except (OSError, ValueError, Image.DecompressionBombError) as exc:
                    raise HTTPException(400, "无效图片成品") from exc
            with store.db() as db:
                db.execute("BEGIN IMMEDIATE")
                # Deletion can happen while an upload is streaming to the temporary file.
                current = own_job(db, job_id, device)
                if current['deleted'] or current['state'] not in {'running', 'uploading'}:
                    raise HTTPException(409, "任务不接受成品")
                storage_check(db, size)
                count = db.execute("SELECT count(*) FROM files WHERE job=?", (job_id,)).fetchone()[0]
                if count >= 8:
                    raise HTTPException(400, "每个任务最多 8 个成品")
                db.execute("INSERT INTO files VALUES(?,?,?,?,?,?,?)", (file_id, job_id, requester, name, types[extension], size, time.time()))
        except Exception:
            path.unlink(missing_ok=True)
            raise
        return {"id": file_id, "name": name, "mime": types[extension], "size": size}

    @app.get("/v1/files/{file_id}")
    def download(file_id: str, device=Depends(auth)):
        with store.db() as db:
            row = db.execute("SELECT * FROM files WHERE id=?", (file_id,)).fetchone()
            if not row:
                raise HTTPException(404, "文件不存在")
            allowed = device["role"] == "mobile" and row["requester"] == device["id"]
            if device["role"] == "worker":
                allowed = bool(db.execute("SELECT id FROM jobs WHERE worker=? AND state IN ('running','uploading') AND json_extract(payload,'$.inputId')=?", (device["id"], file_id)).fetchone())
            if not allowed:
                raise HTTPException(404, "文件不存在")
        return FileResponse(store.root / "files" / row["id"], media_type=row["mime"], filename=row["name"])

    @app.get("/v1/files/{file_id}/thumbnail")
    def thumbnail(file_id: str, device=Depends(mobile)):
        with store.db() as db:
            row = db.execute("SELECT * FROM files WHERE id=? AND requester=?", (file_id, device["id"])).fetchone()
        if not row or not row["mime"].startswith("image/"):
            raise HTTPException(404, "图片不存在")
        with Image.open(store.root / "files" / row["id"], formats=["PNG", "JPEG", "WEBP", "GIF"]) as img:
            img.thumbnail((720, 720))
            buffer = io.BytesIO()
            img.convert("RGB").save(buffer, "JPEG", quality=82)
        return Response(buffer.getvalue(), media_type="image/jpeg")

    return app


def create_mobile_app():
    """Tunnel only this listener. Worker registration and admin surfaces stay local."""
    return create_app(mobile_only=True)
