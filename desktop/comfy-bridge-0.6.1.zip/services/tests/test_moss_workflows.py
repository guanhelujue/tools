import copy

import httpx
import pytest
from fastapi.testclient import TestClient

from test_editable_workflows import info, graph
from toolcase.broker import create_app
from toolcase.desktop_workflows import DesktopWorkflows
from toolcase.workflows import node_catalog, compile_workflow, prepare_workflow


@pytest.fixture
def moss_info(info):
    metadata = copy.deepcopy(info)
    metadata['SkipLayerGuidanceDiTSimple'] = {
        'python_module': 'comfy_extras.nodes_slg', 'output': ['MODEL'],
        'input_order': {'required': ['model', 'double_layers', 'single_layers', 'start_percent', 'end_percent']},
        'input': {'required': {
            'model': ['MODEL', {}],
            'double_layers': ['STRING', {'default': '7, 8, 9', 'advanced': True}],
            'single_layers': ['STRING', {'default': '7, 8, 9', 'advanced': True}],
            'start_percent': ['FLOAT', {'default': 0.0, 'min': 0.0, 'max': 1.0, 'step': .001}],
            'end_percent': ['FLOAT', {'default': 1.0, 'min': 0.0, 'max': 1.0, 'step': .001}],
        }},
    }
    return metadata


@pytest.fixture
def moss_graph(graph):
    source = copy.deepcopy(graph)
    source['8'] = {'class_type': 'SkipLayerGuidanceDiTSimple', 'inputs': {
        'model': ['1', 0], 'double_layers': '0, 1, 2', 'single_layers': '',
        'start_percent': 0.05, 'end_percent': 0.9,
    }}
    source['5']['inputs']['model'] = ['8', 0]
    return source


def test_saved_moss_canvas_keeps_guidance_while_phone_edits_prompt_and_size(moss_info, moss_graph):
    canvas = {'nodes': [], 'links': []}
    for node_id, node in moss_graph.items():
        slots, widgets = [], []
        for key, value in node['inputs'].items():
            if isinstance(value, list):
                link_id = len(canvas['links']) + 1
                kind = moss_info[node['class_type']]['input']['required'][key][0]
                canvas['links'].append([link_id, int(value[0]), value[1], int(node_id), len(slots), kind])
                slots.append({'name': key, 'link': link_id})
            else:
                widgets.append(value)
        canvas['nodes'].append({'id': int(node_id), 'type': node['class_type'], 'inputs': slots, 'widgets_values': widgets})
    original = copy.deepcopy(canvas)
    def handler(request):
        return httpx.Response(200, json=[{'path': 'MOSS/sample.json', 'size': 100, 'modified': 1}] if request.url.path == '/userdata' else canvas)
    with httpx.Client(base_url='http://localhost', transport=httpx.MockTransport(handler)) as client:
        sources, errors = DesktopWorkflows(client).scan(moss_info, force=True)
    assert errors == []
    template = sources[0]
    assert template['workflow']['8'] == moss_graph['8'] | {'_meta': {'title': 'SkipLayerGuidanceDiTSimple'}}
    output = compile_workflow(template, {'prompt': 'lake at sunrise', 'width': 768, 'height': 1024}, None, 'moss-test')
    assert output['2']['inputs']['text'] == 'lake at sunrise'
    assert output['4']['inputs'] == {'width': 768, 'height': 1024, 'batch_size': 1}
    assert output['8'] == template['workflow']['8']
    assert output['5']['inputs']['model'] == ['8', 0]
    assert output['1']['inputs'] == moss_graph['1']['inputs']
    assert canvas == original


def test_moss_mobile_submit_keeps_guidance_and_model_snapshot(tmp_path, moss_info, moss_graph):
    app = create_app(tmp_path)
    client = TestClient(app)
    store = app.state.store
    devices = {role: store.pair(store.create_pairing(role), role) for role in ('worker', 'mobile')}
    headers = {role: {'Authorization': 'Bearer ' + value['token']} for role, value in devices.items()}
    assert client.post('/v1/worker/catalog', headers=headers['worker'], json={'templates': [], 'nodes': node_catalog(moss_info), 'workflowEditing': True}).status_code == 200
    body = {'worker': devices['worker']['deviceId'], 'template': 'desktop-moss', 'requestId': 'moss-test-001',
            'values': {}, 'workflow': {'name': 'MOSS', 'mode': 't2i', 'graph': copy.deepcopy(moss_graph)}}
    body['workflow']['graph']['2']['inputs']['text'] = 'phone prompt'
    body['workflow']['graph']['4']['inputs'].update(width=768, height=1024)
    response = client.post('/v1/jobs', headers=headers['mobile'], json=body)
    assert response.status_code == 201, response.text
    sent = response.json()['payload']['workflow']['graph']
    assert sent['8'] == moss_graph['8']
    prepared = prepare_workflow(sent, node_catalog(moss_info))
    assert compile_workflow(prepared, {}, None, 'moss-validated')['8']['inputs'] == moss_graph['8']['inputs']


@pytest.mark.parametrize('change', ['plugin_override', 'api_node'])
def test_moss_node_requires_reviewed_local_implementation(moss_info, moss_graph, change):
    if change == 'plugin_override':
        moss_info['SkipLayerGuidanceDiTSimple']['python_module'] = 'custom_nodes.unreviewed'
    else:
        moss_info['SkipLayerGuidanceDiTSimple']['api_node'] = True
    assert 'SkipLayerGuidanceDiTSimple' not in node_catalog(moss_info)
    with pytest.raises(ValueError, match='尚未开放'):
        prepare_workflow(moss_graph, node_catalog(moss_info))


def test_moss_guidance_values_still_obey_local_bounds(moss_info, moss_graph):
    moss_graph['8']['inputs']['end_percent'] = 1.5
    with pytest.raises(ValueError):
        prepare_workflow(moss_graph, node_catalog(moss_info))
